// Third part
import { Component } from '@angular/core'
import { NavController, NavParams, MenuController } from 'ionic-angular'

// App Pages
import { EstablishmentsPage } from '../establishments/establishments'
import { EventsPage } from '../events/events'
import { LivePage } from '../live/live'
import { ProfilePage } from '../profile/profile'

// App Providers
import { GlobalService } from '../../providers/global-service'
import { AnalyticsService } from '../../providers/analytics-service'

@Component({
  selector: 'page-main-tabs',
  templateUrl: 'main-tabs.html'
})
export class MainTabsPage {

  tabEstablishments: any = EstablishmentsPage
  tabEvents: any = EventsPage
  tabCamera: any = LivePage
  tabUser: any = ProfilePage

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public menuCtrl: MenuController,
    public globalService: GlobalService,
    public analyticsService: AnalyticsService
  ) {
  }

  public ionViewCanEnter(): boolean {
    return this.globalService.isLogged
  }

  logEvent(eventName: string): void {
    this.analyticsService.log(eventName, {}, 1)
  }

}
