// Third part
import { Component, ViewChild, isDevMode } from '@angular/core'
import { Content } from 'ionic-angular'
import { NavController, NavParams, ModalController } from 'ionic-angular'
import { Keyboard } from '@ionic-native/keyboard'

// Providers
import { ChatApiService } from '../../providers/chat-api-service'
import { GlobalService } from '../../providers/global-service'
import { PusherService } from '../../providers/pusher-service'
import { ModalSniffsFactory } from '../../providers/modal-sniffs-factory'
import { SniffFactory } from '../../providers/sniff-factory'
import { Vibration } from '@ionic-native/vibration'

@Component({
  selector: 'page-chat',
  templateUrl: 'chat.html'
})
export class ChatPage {
  @ViewChild('input') input
	@ViewChild(Content) content: Content
  establishment: any
  currentPage: number = 1
  currentUser: any
  canPostSniff: boolean = false
	chat: any = { }
	message: string = ''
  channel: any

  constructor(
  	public navCtrl: NavController,
  	public navParams: NavParams,
  	public chatApiService: ChatApiService,
    public globalService: GlobalService,
    public modalCtrl: ModalController,
    public PusherService: PusherService,
    public modalSniffsFactory: ModalSniffsFactory,
    public sniffFactory: SniffFactory,
    private keyboard: Keyboard,
    private vibration: Vibration
  ) {
    this.chat = { meta: null, data: null }

    // Listen to keyboard show event and
    // scroll to page content bottom
    if(!isDevMode()) {
      this.keyboard.onKeyboardShow().subscribe(() => {
        this.scrollToBottom(0)
      })
    }

    this.establishment = this.navParams.get('establishment')
    this.currentUser = this.globalService.session

    if(this.currentUser.role === 'owner') {
      for(let e of this.currentUser.establishments) {
        if(e.id === this.establishment.id) {
          this.canPostSniff = true
        }
      }
    }

    this.loadMessages()
  }

  public ionViewWillEnter(): void {
    this.currentUser = this.globalService.session
  }

  // @name loadMessages
  // @description Load chat messages
  // @params { number } page - page to load
  // @returns void
  public loadMessages(page: number = this.currentPage++): void {
    this.chatApiService
        .getMessagesByEstablishment(this.establishment, { page })
        .subscribe(this._aftergetMessagesByEstablishment.bind(this))
  }

  // @name _aftergetMessagesByEstablishment
  // @description Callback after get messages
  // @params { Object } res - Chat response API
  // @returns void
  private _aftergetMessagesByEstablishment(res): void {
    this.chat.meta = res.meta

    // Reverse messages because we need chat behavior
    res.data.messages = res.data.messages.reverse()

    // If has data, we use unshift method to insert
    // data in the beggining of the array
    if(this.chat.data && this.chat.data.messages) {
      this.chat.data.messages.unshift(...res.data.messages)
    } else {
      this.chat.data = res.data

      // First access must scroll to bottom of the page
      this.scrollToBottom()
    }
    // Listen to pusher events
    this._listenPusher()
  }

  // @name _listenPusher
  // @description listen tu pusher events
  // @returns void
  private _listenPusher(): void {
    if(!this.channel) {

      // Subscribe chat channel
      this.channel = this.PusherService.connection
                          .subscribe(`chat-${this.chat.data.id}`)

      // Bind new message event
      this.channel.bind('new:message', this._onNewMessage.bind(this))
    }
  }

  // @name _onNewMessage
  // @description callback exec after receive a new message
  // @params { Object } res - Chat message object
  // @returns void
  private _onNewMessage(res): void {
    const chatMessage = res.data

    // Prevent to add twice the message if was the user that sends this message
    if(chatMessage.user.id !== this.currentUser.id) {
      this.chat.data.messages.push(res.data)

      this.vibration.vibrate(300)

      // TODO - Scroll only if the user is in the bottom of the page
      this.scrollToBottom()
    }
  }

  // @name send
  // @description send message or open camera
  // @returns void
  public send(event: any): any {
    if(this.message) {
      this.input.setFocus()
      this._sendMessage()
    } else {
      this.sniffFactory.send({ establishment: this.establishment })
    }
  }

  // @name _sendMessage
  // @description send message via API
  // @returns void
  private _sendMessage() {
    const { message } = this
    this.message = null

    // Add message in the array
    // We add before send to api to provide
    // a real time sensation
    this.chat.data.messages.push({
      user: {
        name: this.currentUser.name,
        id: this.currentUser.id
      },
      content: message,
      not_confirmed: true,
      failed: false
    })

    this.scrollToBottom()

    // Send via API
    this.chatApiService
        .createMessage(this.establishment, this.chat.data, { content: message })
        .subscribe(this._afterSendMessage.bind(this))
  }

  // @name _afterSendMessage
  // @description callback after send message via API
  // @params { Object } res - API response
  private _afterSendMessage(res) {

    // Iterate over all messages
    for(let i in this.chat.data.messages) {
      let chatMessage = this.chat.data.messages[i]

      // Message is not confirmed
      if(chatMessage.not_confirmed) {

        // Check if the message is the same
        // If is the same, remove the clock icon and insert the time
        // that was created
        if(res.data.content === chatMessage.content) {
          chatMessage.not_confirmed = false
          chatMessage.created_at = res.data.created_at
          chatMessage.id = res.data.id

          break;
        }
      }
    }
  }

  // @name resendMessage
  // @description Resend a message with err
  // @params { Object } message to resend
  // @returns void
  public resendMessage(message): void {
    this.chatApiService
        .createMessage(this.establishment, this.chat.data, { content: message.content })
        .subscribe(this._afterSendMessage.bind(this))
  }

  // @name openSniffs
  // @description Open modal sniff factory
  // @returns void
  public openSniffs(): void {
    this.modalSniffsFactory
        .open(this.establishment)
  }

  // @name scrollToBottom
  // @description scroll to bottom of the page
  // @params { Number } timeout - Throttle time
  public scrollToBottom(timeout: number = 300): void {
    setTimeout(() => {
      if(this.content) {
        this.content.scrollToBottom()
      }
    }, timeout)
  }
}
