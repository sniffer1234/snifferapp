import { Component } from '@angular/core'
import { AlertController } from 'ionic-angular'
import { Validators, FormBuilder } from '@angular/forms'
import { NavController } from 'ionic-angular'

// Providers
import { LoginApiService } from '../../providers/login-api-service'
import { GlobalService } from '../../providers/global-service'
import { RegisterApiService } from '../../providers/register-api-service'
import { FacebookService } from '../../providers/facebook-service'
import { AnalyticsService } from '../../providers/analytics-service'

// Pages
import { MainTabsPage } from '../main-tabs/main-tabs'
import { LoginPage } from '../login/login'

@Component({
  selector: 'page-register',
  templateUrl: 'register.html'
})
export class RegisterPage {

	registerForm: any

  constructor(
    public formBuilder: FormBuilder,
    public alertCtrl: AlertController,
    public navCtrl: NavController,
    public registerApiService: RegisterApiService,
    public loginApiService: LoginApiService,
    public globalService: GlobalService,
    public facebookService: FacebookService,
    public analyticsService: AnalyticsService
  ) {
  	this.registerForm = this.formBuilder.group({
      name: ['', Validators.required],
  		email: ['', [Validators.required, Validators.pattern('^[a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,15})$')]],
  		password: ['', Validators.required],
  		password_confirmation: ['', Validators.required]
  	})
  }

  // @name submitRegisterForm
  // @description Submit registration data
  // @returns void
  public submitRegisterForm(): void {
  	this.registerApiService
  			.signup(this.registerForm.value)
  			.subscribe(this.afterRegister.bind(this))
  }

  // @name _afterRegister
  // @description Submit Callback after register
  // @returns void
  private afterRegister(res: any): void {
    this.analyticsService.log('Cadastro', {}, 1)
    this.globalService.session = res.data

    const alert = this.alertCtrl.create({
      enableBackdropDismiss: false,
      title: 'Olá',
      subTitle: `Seja bem-vindo(a), ${ res.data.first_name }`,
      buttons: [{
        text: 'OK',
        handler: () => {
          this.navCtrl.setRoot(MainTabsPage)
        }
      }]
    })

    alert.present()
  }

  // @name loginWithFacebook
  public loginWithFacebook(): void {
    this.facebookService.login().then(this.afterRegister.bind(this))
  }

  // @name openLoginPage
  // @description open login page
  // @returns void
  public openLoginPage(): void {
    this.navCtrl.push(LoginPage)
  }

}
