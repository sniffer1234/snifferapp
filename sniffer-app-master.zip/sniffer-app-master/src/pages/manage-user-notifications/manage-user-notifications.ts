import { Component } from '@angular/core'
import { Events, NavController } from 'ionic-angular'
import { AlertService } from '../../providers/alert-service';
import { GlobalService } from '../../providers/global-service'
import { MeApiService } from '../../providers/me-api-service'

@Component({
  selector: 'page-manage-user-notifications',
  templateUrl: 'manage-user-notifications.html'
})
export class ManageUserNotificationsPage {
  currentUser: any

  constructor(
    public navCtrl: NavController,
    public events: Events,
    public globalService: GlobalService,
    public meApiService: MeApiService,
    public alert: AlertService
  ) {
    this.currentUser = this.globalService.session
  }

  public submit(): void {
    this.meApiService
        .update(this.currentUser)
        .subscribe(this._afterSubmit.bind(this))
  }

  private _afterSubmit(res): void {
    this.globalService.session = res.data

    this.alert.show({
      content: 'Notificações atualizadas com sucesso',
      vibrate: true
    }).then(() => {
      this.navCtrl.pop()
    })
  }


}
