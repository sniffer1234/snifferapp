import { Component } from '@angular/core'
import { NavController, NavParams, ToastController, ModalController } from 'ionic-angular'
import { EstablishmentApiService } from '../../providers/establishment-api-service'
import { TagsApiService } from '../../providers/tags-api-service'
import { GlobalService } from '../../providers/global-service'
import { AnalyticsService } from '../../providers/analytics-service'
import { SuggestEstablishmentComponent } from '../../components/suggest-establishment/suggest-establishment'
import { TagSearchComponent } from '../../components/tag-search/tag-search'

@Component({
  selector: 'page-establishments',
  templateUrl: 'establishments.html'
})
export class EstablishmentsPage {

	establishments: any = {}
  tags: any = null
  searchTerms: string = ''
  searchTag: string = 'all'
  showReloadingButton: boolean = false

  constructor(
  	public navCtrl: NavController,
  	public navParams: NavParams,
    public modalCtrl: ModalController,
    public toastCtrl: ToastController,
    public establishmentApiService: EstablishmentApiService,
    public tagsApiService: TagsApiService,
    public globalService: GlobalService,
    public analyticsService: AnalyticsService,
  ) {
    this.loadTags()
    this.loadEstablishments()
  }

  public ionViewWillEnter(): void {
  }

  public ionViewDidLeave(): void {
    this.showReloadingButton = true
    this.clearSearch()
  }

  // @name loadEstablishments
  // @description load establishments
  // @params { Object } params - api params
  // @returns void
  private loadEstablishments(options: any = {}): void {
    let params: any = {}
    let extraParams: any = {}

    if(this.searchTerms) {
      params.search = this.searchTerms
    }

    if(this.searchTag) {
      params.tags = this.searchTag
    }

    if(options.bySearchBar) {
      extraParams.hideLoading = true
    }

    this.establishmentApiService
        .getAll(params, extraParams)
        .subscribe(this.afterGetEstablishments.bind(this))
  }

  // @name afterGetEstablishments
  // @description callback after get establishments
  // @params { Object } res - api response
  // @returns void
  public afterGetEstablishments(res): void {
    this.establishments = res
    this.globalService.establishments = res
  }

  // @name loadTags
  // @description load tags
  // @params { Object } params - api params
  // @returns void
  private loadTags(): void {
    this.tagsApiService
        .getAll()
        .subscribe(this.afterGetTags.bind(this))
  }

  // @name afterGetTags
  // @description callback after get tags
  // @params { Object } res - api response
  // @returns void
  private afterGetTags(res): void {
    this.tags = res
  }

  // @name searchByTag
  // @description search by selected tag
  // @params { Object } tag
  // @returns void
  searchByTag(tag) {
    if(!this.globalService.showedTagToast) {

      let toast = this.toastCtrl.create({
        message: 'Pressione novamente na tag para remover o filtro',
        duration: 5000,
        position: 'bottom'
      })

      toast.present()

      // Set on storage to not show again
      this.globalService.showedTagToast = true
    }

    this.searchTag = tag ? tag.name.toLowerCase() : null
    this.loadEstablishments()
  }

  // @name loadMore
  // @description load more data in infinite way
  // @params { Object } infiniteScroll - ionic event
  // @returns void
  public loadMore(infiniteScroll: any): void {
    const params = { search: this.searchTerms, tags: this.searchTag, page: this.establishments.meta.next_page  }
    const extraParams = { hideLoading: true }

    // Avoid to show more page if does not has more results
    if(this.establishments.meta.next_page) {
      this.establishmentApiService
        .getAll(params, extraParams)
        .subscribe((res) => {

          // Stop to show loading hint
          infiniteScroll.complete()

          // Override arrays
          this.establishments.data.push(...res.data)
          this.establishments.meta = res.meta

          this.globalService.establishments = this.establishments
        })
    } else {

      // Stop event
      infiniteScroll.complete()
    }
  }

  // @name openSuggestModal
  // @description show suggestion modal
  // @returns void
  public openSuggestModal(): void {
    const suggestModal = this.modalCtrl.create(SuggestEstablishmentComponent)
    suggestModal.present()
  }

  // @name clearSearch
  // @descripton remove search
  // @returns void
  public clearSearch():void {
    this.searchTerms = ''
    this.searchTag = 'all'
  }
}
