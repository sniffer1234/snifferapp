import { Component } from '@angular/core'
import { NavController, NavParams } from 'ionic-angular'
import { LoginPage } from '../login/login'

@Component({
  selector: 'page-tutorial',
  templateUrl: 'tutorial.html'
})
export class TutorialPage {
	slides: Array<{title: string, description: string, image: string}>

  constructor(
  	public navCtrl: NavController,
  	public navParams: NavParams
  ) {
  	this.slides = [
  		{
  			title: 'Seja bem vindo',
  			description: 'Com o Sniffer você ficará por dentro dos melhores lugares e eventos que acontecem em sua cidade.',
  			image: 'assets/img/tutorial-1.png'
  		},
  		{
  			title: 'Saiba o que acontece',
  			description: 'Saiba mais sobre seus estabelecimentos favoritos através de um chat que conecta todos os seus frequentadores.',
  			image: 'assets/img/tutorial-2.png'
  		},
      {
  			title: 'Compartilhe',
  			description: 'Compartilhe suas experiências com os outros usuários.',
  			image: 'assets/img/tutorial-3.png'
  		}
  	]
  }

  // @description Open Home page
  public openLoginPage(): void {
  	this.navCtrl.push(LoginPage)
  }

}
