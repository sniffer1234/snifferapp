// Third part
import { Component } from '@angular/core'
import { Validators, FormBuilder } from '@angular/forms'
import { NavController, AlertController, NavParams, ToastController } from 'ionic-angular'

// Providers
import { LoginApiService } from '../../providers/login-api-service'
import { GlobalService } from '../../providers/global-service'
import { FacebookService } from '../../providers/facebook-service'
import { AnalyticsService } from '../../providers/analytics-service'

// Pages
import { MainTabsPage } from '../main-tabs/main-tabs'
import { RecoverPasswordPage } from '../recover-password/recover-password'
import { RegisterPage } from '../register/register'

@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {

  loginForm: any
  failureCount: number = 0
  resetToast: any

  constructor(
    public navCtrl: NavController,
    public alertCtrl: AlertController,
    public navParams: NavParams,
    public toastCtrl: ToastController,
    private formBuilder: FormBuilder,
    public loginApiService: LoginApiService,
    public globalService: GlobalService,
    public facebookService: FacebookService,
    public analyticsService: AnalyticsService
  ) {

    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern('^[a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,15})$')]],
      password: ['', Validators.required]
    })
  }

  // @name submitLoginForm
  // @description Authenticate user
  // @returns void
  public submitLoginForm(): void {
    this.loginApiService
        .signin(this.loginForm.value)
        .subscribe(
          this.afterLogin.bind(this),
          this.afterLoginErr.bind(this)
        )
  }

  // @name _afterLogin
  // @description Callback after user authenticates
  // @params { Object } res - API response
  // @returns void
  private afterLogin(res): void {
    this.analyticsService.log('Login', {}, 1)

    this.globalService.session = res.data

    const alert = this.alertCtrl.create({
      enableBackdropDismiss: false,
      title: 'Você está logado(a)',
      subTitle: `Olá ${ res.data.first_name }`,
      buttons: [{
        text: 'OK',
        handler: () => {
          this.navCtrl.setRoot(MainTabsPage)
        }
      }]
    })

    alert.present()
  }

  // @name _afterLoginErr
  // @description Callback when user trys to login but failed
  // @returns void
  private afterLoginErr(err: any): void {
    this.failureCount += 1

    if(this.failureCount === 2 || this.failureCount === 3) {
      if(this.resetToast) {
        this.resetToast.dismiss()
      }

      this.resetToast = this.toastCtrl.create({
        dismissOnPageChange: true,
        message: 'Parece que você não consegue fazer login. Deseja recuperar sua senha?',
        duration: 6000,
        closeButtonText: 'Sim',
        showCloseButton: true,
        position: 'bottom'
      })

      this.resetToast.present()

      this.resetToast.onDidDismiss((data, role) => {
        this.resetToast = null

        if(role === 'close') {
          this.redirectToRecoverPassword()
        }
      })
    }
  }

  // @name _redirectToRecoverPassword
  // @description Redirect user to redefine password page
  // @returns void
  private redirectToRecoverPassword(): void {
    const { email } = this.loginForm.value
    this.navCtrl.push(RecoverPasswordPage, { email })
  }

  // @name loginWithFacebook
  // @description make login with facebook service
  // @returns void
  public loginWithFacebook(): void {
    this.facebookService.login().then(this.afterLogin.bind(this))
  }

  // @name openRecoverPasswordPage
  // @description Open recovery password page
  // @returns void
  public openRecoverPasswordPage(): void {
    this.navCtrl.push(RecoverPasswordPage)
  }

  // @name openRegistrationPage
  // @description Open registration page
  // @returns void
  public openRegistrationPage(): void {
    this.navCtrl.push(RegisterPage)
  }

}
