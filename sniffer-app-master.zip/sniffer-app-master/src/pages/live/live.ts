// Third part
import { Component, ViewChildren } from '@angular/core'
import { NavController, NavParams, ModalController, ToastController } from 'ionic-angular'

// Pages
import { EstablishmentDetailPage } from '../../pages/establishment-detail/establishment-detail'

// Providers
import { EstablishmentApiService } from '../../providers/establishment-api-service'
import { SniffApiService } from '../../providers/sniff-api-provider'
import { MeApiService } from '../../providers/me-api-service'
import { GlobalService } from '../../providers/global-service'
import { ModalSniffsFactory } from '../../providers/modal-sniffs-factory'
import { SniffFactory } from '../../providers/sniff-factory'
import { AnalyticsService } from '../../providers/analytics-service'

@Component({
  selector: 'page-live',
  templateUrl: 'live.html'
})
export class LivePage {

  @ViewChildren('sniffItens') sniffItens
	sniffs: any
	mySniffs: any
  currentUser: any
  sniffsInterval: any
  showMySniffsList: boolean = false
  video: any

  constructor(
  	public navCtrl: NavController,
  	public navParams: NavParams,
  	public sniffApiService: SniffApiService,
    public establishmentApiService: EstablishmentApiService,
    public meApiService: MeApiService,
    public modalCtrl: ModalController,
    public toastCtrl: ToastController,
    public modalSniffsFactory: ModalSniffsFactory,
    public sniffFactory: SniffFactory,
    public globalService: GlobalService,
    public analyticsService: AnalyticsService
  ) {
    this.loadSniffs()
    this.loadMySniffs()

    this.currentUser = this.globalService.session
  }

  private initSniffInterval(): void {
    clearInterval(this.sniffsInterval)

    this.sniffsInterval = setInterval(() => {
      this.loadSniffs({}, { hideLoading: true })
    }, 25000)
  }

  // @name ionViewWillEnter
  // @description callback when page will enter
  // @returns void
  public ionViewWillEnter(): void {
    this.initSniffInterval()
  }

  // @name ionViewDidLeave
  // @description callback when page leaves
  // @returns void
  public ionViewDidLeave(): void {
    clearInterval(this.sniffsInterval)
  }

  // @name loadMySniffs
  // @description load sniffs by user
  // @returns void
  public loadMySniffs(options: any = {}, extraOptions: any = {}): void {
    this.meApiService.getSniffs(options, extraOptions).subscribe((res) => {
      this.mySniffs = res
    })
  }

  // @name loadSniffs
  // @description load sniffs data via api
  // returns void
  public loadSniffs(options: any = {}, extraOptions: any = {}): void {
    this.sniffApiService
        .getLastSniffsByEstablishments(options, extraOptions)
        .subscribe(this._afterLoad.bind(this))
  }

  // @name afterLoad
  // @description callback after load sniffs
  // @params { Object } Api response
  // @returns void
  private _afterLoad(res: any): void {
    this.sniffs = res
  }

  // @name loadMore
  // @description Load more sniff data using infiniteScroll
  // @params { Object } infiniteScroll component
  // @returns void
  public loadMore(infiniteScroll: any): void {
    if(this.sniffs.meta.next_page) {
      this.sniffApiService
        .getLastSniffsByEstablishments({ page: this.sniffs.meta.next_page }, { hideLoading: true })
        .subscribe((res) => {

          // Stop to show loading hint
          infiniteScroll.complete()

          // Override arrays
          this.sniffs.data.push(...res.data)
          this.sniffs.meta = res.meta
        })
    } else {

      // Stop event
      infiniteScroll.complete()
    }
  }

  // @name showSniffsByEstablishment
  // @description
  // @params
  // @returns void
  public showSniffsByEstablishment(establishment): void {
    this.modalSniffsFactory
        .open(establishment)
        .then(this.afterCloseSniffsModal.bind(this))
  }

  // @name _afterCloseSniffsModal
  // @description callback after close sniff modals
  // @params { Object } data - action to perform
  private afterCloseSniffsModal(data: any = null): void {

    // User tapped on establishment name,
    // so we close the sniffs modal and redirect
    // to the establishment page
    if(data && data.redirectToEstablishment) {

      // Fetch establishment data
      this.establishmentApiService
        .getOne({ id: data.establishment.id })
        .subscribe((res) => {
          this.navCtrl.push(EstablishmentDetailPage, {
            establishment: res.data
          })
      })
    }
  }

  // @name startToSendSniff
  // @description Initialise the process to send a sniff
  // @return void
  public send(): void {
    this.analyticsService.log('Clique na câmera aba sniffs', {}, 1)
    this.sniffFactory.send().then(this.afterSend.bind(this))
  }

  // @name afterSend
  // @description callback after send sniff
  // @return void
  private afterSend(): void {
    this.initSniffInterval()

    this.loadMySniffs()
    this.loadSniffs({}, { hideLoading: true })
  }

  // @name toggleMySniffsList
  // @description toggle my sniffs value
  // @returns void
  public toggleMySniffsList(): void {
    this.showMySniffsList = !this.showMySniffsList
  }
}
