// Third part
import { Component } from '@angular/core'
import { NavController, NavParams, ModalController } from 'ionic-angular'

// App services
import { EventApiService } from '../../providers/event-api-service'
import { TagsApiService } from '../../providers/tags-api-service'
import { AnalyticsService } from '../../providers/analytics-service'

// App components
import { SuggestEventComponent } from '../../components/suggest-event/suggest-event'

@Component({
  selector: 'page-events',
  templateUrl: 'events.html'
})
export class EventsPage {

	events: any
  tags: any = null
  query: any = {}
  search: string = ''
  showReloadingButton: boolean = false

  constructor(
  	public navCtrl: NavController,
  	public navParams: NavParams,
    public eventApiService: EventApiService,
    public tagsApiService: TagsApiService,
    public modalCtrl: ModalController,
    public analyticsService: AnalyticsService,
  ) {
    this.loadEvents()
  }

  public ionViewWillEnter(): void {
  }

  public ionViewDidLeave(): void {
    this.showReloadingButton = true
    this.query = {}
  }

  // @name loadEvents
  // @description load events via api
  // @returns void
  private loadEvents(hideLoading: boolean = false): void {
    const params = { search: this.search, tags: this.query.tags }

    this.eventApiService
        .getAll(params, { hideLoading: this.search ? true : false })
        .subscribe(this.afterLoad.bind(this))
  }

  // @name afterLoad
  // @description callback after receive api data
  // @params { Object } - Api response
  private afterLoad(res): void {
    this.events = res
  }

  // @name openSuggestModal
  // @description open event suggestion modal
  // @returns void
  public openSuggestModal(): void {
    const suggestModal = this.modalCtrl.create(SuggestEventComponent)
    suggestModal.present()
  }

  // @name cleanSearch
  // @descripton remove search
  // @returns void
  public cleanSearch():void {
    this.query = {}
    this.loadEvents()
  }
}
