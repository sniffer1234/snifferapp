// Third part
import { Component } from '@angular/core'
import { NavController, ActionSheetController, Events } from 'ionic-angular'
import { Camera } from '@ionic-native/camera'
import { PhotoViewer } from '@ionic-native/photo-viewer'
import { Toast  } from '@ionic-native/toast'

// App services
import { GlobalService } from '../../providers/global-service'
import { MeApiService } from '../../providers/me-api-service'

// App pages
import { SendSuggestionPage } from '../send-suggestion/send-suggestion'
import { EditUserDataPage } from '../edit-user-data/edit-user-data'
import { RedefineProfilePasswordPage } from '../redefine-profile-password/redefine-profile-password'
import { ManageUserNotificationsPage } from '../manage-user-notifications/manage-user-notifications'

@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html'
})
export class ProfilePage {
  currentUser: any
  cameraOptions: any
  galleryOptions: any

  constructor(
    public navCtrl: NavController,
    public events: Events,
    public actionSheetCtrl: ActionSheetController,
    public globalService: GlobalService,
    public meApiService: MeApiService,
    private camera: Camera,
    private photoViewer: PhotoViewer,
    private toast: Toast
  ) {
    this.cameraOptions = {
      camera: {
        quality: 100,
        destinationType: this.camera.DestinationType.DATA_URL,
        encodingType: this.camera.EncodingType.JPEG
      },
      gallery: {
        quality: 100,
        sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
        destinationType: this.camera.DestinationType.DATA_URL,
        encodingType: this.camera.EncodingType.JPEG
      }
    }
  }

  // @name ionViewWillEnter
  // @description callback when page will enter
  // @returns voi
  public ionViewWillEnter(): void {
    this.currentUser = this.globalService.session
  }

  // @name showAvatar
  // @description Show user avatar using photo views native plugin
  // @returns void
  public showAvatar(): void {
    this.photoViewer.show(this.currentUser.avatar.medium)
  }

  // @name openActionSheet
  // @description Open action sheet component to change avatar
  // @returns void
  public openActionSheet(): void {
    let actionSheet = this.actionSheetCtrl.create({
      title: 'Alterar avatar',
      buttons: [
        { text: 'Tirar foto', icon: 'camera', handler: this.openCamera.bind(this, 'camera') },
        { text: 'Buscar na galeria', icon: 'images', handler: this.openCamera.bind(this, 'gallery') },
        { text: 'Fechar', role: 'cancel', icon: 'close' }
      ]
    })

    actionSheet.present()
  }

  // @name openCamera
  // @description open native camera / gallery
  // @returns void
  private openCamera(type: string): void {
    const options = this.cameraOptions[type]

    this.camera.getPicture(options)
      .then(
        this._afterGetImage.bind(this),
        this._afterGetImageWithErr.bind(this)
      )
  }

  // @name _afterGetImage
  // @description Callback executed after get image on camera or gallery
  // @params { string } imgData - image in base64 format
  // @returns void
  private _afterGetImage(imgData: any): void {

    // Necessary to API understand
    const avatarData = `data:image/jpeg;base64,${ imgData }`

    // Update on API
    this.meApiService
      .update({ avatar_data: avatarData })
      .subscribe(this._afterChangeimage.bind(this))
  }

  // @name _afterChangeimage
  // @description callback after change image
  // @params { Object } res - Api response
  // @returns void
  public _afterChangeimage(res): void {
    this.globalService.session = res.data
    this.currentUser = this.globalService.session

    this.toast.show('Avatar alterado', '4000', 'bottom').subscribe()
  }

  // @name _afterGetImageWithErr
  // @description Callback when an error occurs when using cordova camera
  // @params { Object } Error details
  // @returns void
  private _afterGetImageWithErr(err): void {
    // TODO
  }

  // @name goTo
  // @description Go to a specific page
  // @params { String } pageName - page to redirect
  // @returns void
  public goTo(pageName: string): void {
    if(pageName === 'editUserData') {
      this.navCtrl.push(EditUserDataPage)
    } else if(pageName === 'redefineProfilePassword') {
      this.navCtrl.push(RedefineProfilePasswordPage)
    } else if(pageName === 'sendSuggestion') {
      this.navCtrl.push(SendSuggestionPage)
    } else {
      this.navCtrl.push(ManageUserNotificationsPage)
    }
  }

  // @name logout
  // @description redirect user to logout
  // @returns void
  public logout(): void {
    this.events.publish('logout')
  }
}
