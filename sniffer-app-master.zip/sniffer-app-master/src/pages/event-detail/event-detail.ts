// Third part
import { Component } from '@angular/core'
import { NavController, NavParams } from 'ionic-angular'
import { PhotoViewer } from '@ionic-native/photo-viewer'
import { SocialSharing } from '@ionic-native/social-sharing'

// App pages
import { EstablishmentDetailPage } from '../../pages/establishment-detail/establishment-detail'

// App providers
import { EstablishmentApiService } from '../../providers/establishment-api-service'
import { AnalyticsService } from '../../providers/analytics-service'


@Component({
  selector: 'page-event-detail',
  templateUrl: 'event-detail.html'
})
export class EventDetailPage {

	event: any

  constructor(
  	public navCtrl: NavController,
  	public navParams: NavParams,
    public establishmentApiService: EstablishmentApiService,
    public analyticsService: AnalyticsService,
    private socialSharing: SocialSharing,
    private photoViewer: PhotoViewer
  ) {
    this.event = this.navParams.get('event')

    this.analyticsService.log('Detalhes evento', {
      name: this.event.name
    }, 1)
  }

  // @name openEstablishment
  // @description Open establishment details
  // @returns void
  public openEstablishment(): void {

    // Load first to avoid extra hints on the establishment page
    this.establishmentApiService
        .getOne({ id: this.event.establishment.id })
        .subscribe(this._afterLoadEstablishment.bind(this))
  }

  // @name _afterLoad
  // @description After load establishment
  // @response { Object } API response
  // @returns void
  private _afterLoadEstablishment(res): void {
    const establishment = res.data

    this.navCtrl.push(EstablishmentDetailPage, {
      establishment
    })
  }

  // @name share
  // @description share via social with native plugin
  // @returns void
  public share(): void {
    let options = {
      message: this.event.small_description,
      subject: this.event.name,
      files: [this.event.cover.large],
      chooserTitle: this.event.name
    }

    this.socialSharing.shareWithOptions(options)
  }

  // @name showImage
  // @description Show image details in fullscreen with native plugin
  // @returns void
  public showImage(): void {
    this.photoViewer.show(this.event.cover.large)
  }

}
