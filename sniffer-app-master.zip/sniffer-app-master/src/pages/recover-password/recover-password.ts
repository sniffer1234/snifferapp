// Third part
import { Component } from '@angular/core'
import { Validators, FormBuilder } from '@angular/forms'
import { NavParams } from 'ionic-angular'

// App services
import { PasswordApiService } from '../../providers/password-api-service'
import { AlertService } from '../../providers/alert-service'

@Component({
  selector: 'page-recover-password',
  templateUrl: 'recover-password.html'
})
export class RecoverPasswordPage {

	passwordForm: any

  constructor(
  	private formBuilder: FormBuilder,
  	public passwordApiService: PasswordApiService,
    public navParams: NavParams,
    public alert: AlertService
  ) {
    const email = navParams.get('email') || ''

  	this.passwordForm = this.formBuilder.group ({
  		email: [email, [Validators.required, Validators.pattern('^[a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,15})$')]]
  	})
  }

  // @name recoverPasswordForm
  // @description Recover password
  // @returns void
  public recoverPasswordForm(): void {
    this.passwordApiService
  		.sendInstructions(this.passwordForm.value)
  		.subscribe(this.afterSendInstructions.bind(this))
  }

  // @name afterSendInstructions
  // @description Callback after send instructions
  // @returns void
  private afterSendInstructions(): void {
    this.passwordForm.reset()

    this.alert.show({
      title: 'Sucesso',
      content: 'Um link para recuperação de senha foi enviado para o seu email. Confira sua caixa de span caso não chegue.'
    })
  }

}
