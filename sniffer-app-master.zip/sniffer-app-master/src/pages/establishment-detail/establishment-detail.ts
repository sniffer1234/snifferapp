// Third part
import { Component } from '@angular/core'
import { NavController, NavParams } from 'ionic-angular'
import { PhotoViewer } from '@ionic-native/photo-viewer'
import { SocialSharing } from '@ionic-native/social-sharing'

// Pages
import { ChatPage } from '../chat/chat'

// Providers
import { AnalyticsService } from '../../providers/analytics-service'

@Component({
  selector: 'page-establishment-detail',
  templateUrl: 'establishment-detail.html'
})
export class EstablishmentDetailPage {

  establishment: any
  tabs: any

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public analyticsService: AnalyticsService,
    private photoViewer: PhotoViewer,
    private socialSharing: SocialSharing
  ){
    this.establishment = navParams.get('establishment')
    this.analyticsService.log('Detalhes estabelecimento', {
      name: this.establishment.name
    }, 1)
  }

  // @ionViewDidEnter
  // @description Callback when view starts. Necessary when user
  // back to this page and prevent to show a blank tab
  // @returns void
  public ionViewDidEnter(): void {
    this.tabs =
      (this.tabs === 'details' || this.tabs === 'events') ?
        this.tabs : 'details'
  }

  // @openChatPage
  // @description Open chat page
  // @returns void
  public openChatPage(): void {
    const establishment = this.establishment

    this.navCtrl.push(ChatPage, {
      establishment
    })
  }

  // @name showImage
  // @description Show establishment image using cordova native plugin
  public showImage(): void {
    this.photoViewer.show(this.establishment.cover.large)
  }

  // @name share
  // @description share in social apps with native plugin
  // @returns void
  public share(): void {
    let options = {
      message: this.establishment.small_description,
      subject: this.establishment.name,
      files: [this.establishment.cover.large],
      chooserTitle: this.establishment.name
    }

    this.socialSharing.shareWithOptions(options)
  }

}
