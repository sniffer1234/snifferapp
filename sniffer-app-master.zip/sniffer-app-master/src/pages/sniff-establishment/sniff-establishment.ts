// Third part
import { Component } from '@angular/core'
import { ViewController, NavParams } from 'ionic-angular'

@Component({
  selector: 'page-sniff-establishment',
  templateUrl: 'sniff-establishment.html'
})
export class SniffEstablishmentPage {
  establishments: any

  constructor(
    public viewCtrl: ViewController,
    public navParams: NavParams
  ) {
    this.establishments = this.navParams.get('establishments')
  }

  // @name select
  // @description select establishment to post a sniff
  // @params { Object } establishment - establisment to post a sniff
  // @returns void
  public select(establishment): void {
    this.viewCtrl.dismiss({
      establishment
    })
  }

  // @name close
  // @description close modal
  // @returns void
  public close(): void {
    this.viewCtrl.dismiss()
  }
}
