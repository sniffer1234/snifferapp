// Third part
import { Component } from '@angular/core'
import { Validators, FormBuilder } from '@angular/forms'
import { Toast  } from '@ionic-native/toast'

// Providers
import { GlobalService } from '../../providers/global-service'
import { MeApiService } from '../../providers/me-api-service'

@Component({
  selector: 'page-edit-user-data',
  templateUrl: 'edit-user-data.html'
})
export class EditUserDataPage {

	form: any
  currentUser: any

  constructor(
  	public formCtrl: FormBuilder,
    public globalService: GlobalService,
    public meApiService: MeApiService,
    private toast: Toast
  ) {
    this.currentUser = this.globalService.session

  	this.form = this.formCtrl.group({
  		name: [this.currentUser.name, Validators.required],
      email: [{value: this.currentUser.email, disabled: true}, Validators.required],
  		cellphone: [this.currentUser.cellphone],
  	})
  }

  // @name submit
  // @description submit edit form
  // @returns void
  public submit(): void {
    this.meApiService
      .update(this.form.value)
      .subscribe(this._afterSubmit.bind(this))
  }

  // @name _afterSubmit
  // @description Callback after submit data to api
  // @params { Object } res - API Response
  // @returns void
  private _afterSubmit(res): void {
    this.globalService.session = res.data
    this.toast.show('Seus dados foram atualizados com sucesso', '4000', 'bottom').subscribe()
  }

}
