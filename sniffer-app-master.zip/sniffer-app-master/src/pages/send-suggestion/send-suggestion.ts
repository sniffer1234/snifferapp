import { Component } from '@angular/core'
import { Validators, FormBuilder } from '@angular/forms'
import { NavController, NavParams } from 'ionic-angular'
import { Toast  } from '@ionic-native/toast'

import { SuggestionApiService } from '../../providers/suggestion-api-service'

@Component({
  selector: 'page-send-suggestion',
  templateUrl: 'send-suggestion.html'
})
export class SendSuggestionPage {
  form: any

  constructor(
    public formCtrl: FormBuilder,
    public navCtrl: NavController,
    public navParams: NavParams,
    public suggestionApiService: SuggestionApiService,
    private toast: Toast
  ){
    this.form = this.formCtrl.group({
  		content: ['', Validators.required]
  	})
  }

  // @name submit
  // @description send suggestion
  // @returns void
  public submit(): void {
    this.suggestionApiService
        .create(this.form.value)
        .subscribe(this.afterSubmit.bind(this))
  }

  // @name afterSubmit
  // @description callback after send a suggestion
  // @returns void
  private afterSubmit(): void {
    this.form.reset()
    this.toast.show('Sugestão enviada. Obrigado.', '3000', 'bottom').subscribe()
  }

}
