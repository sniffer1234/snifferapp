import { Component } from '@angular/core'
import { Validators, FormBuilder } from '@angular/forms'
import { Toast  } from '@ionic-native/toast'
import { GlobalService } from '../../providers/global-service'
import { MeApiService } from '../../providers/me-api-service';

@Component({
  selector: 'page-redefine-profile-password',
  templateUrl: 'redefine-profile-password.html'
})
export class RedefineProfilePasswordPage {

  form: any
  currentUser: any

  constructor(
  	public formCtrl: FormBuilder,
    public globalService: GlobalService,
    public meApiService: MeApiService,
    private toast: Toast
  ) {
  	this.form = this.formCtrl.group({
  		current_password: ['', Validators.required],
  		password: ['', Validators.required],
  		password_confirmation: ['', Validators.required]
  	})
  }

  public ionViewWillEnter(): void {
    this.currentUser = this.globalService.session
  }

  // @name submit
  // @description submit profile password
  // @returns void
  public submit(): void {
    this.meApiService
      .changePassword(this.form.value)
      .subscribe(this._afterSubmit.bind(this))
  }

  // @name _afterSubmit
  // @description callback after change password
  // @returns void
  private _afterSubmit(): void  {
    this.form.reset()
    this.toast.show('Senha alterada com sucesso', '4000', 'bottom').subscribe()
  }

}
