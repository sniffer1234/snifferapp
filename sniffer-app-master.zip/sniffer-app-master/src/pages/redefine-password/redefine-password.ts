import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder } from '@angular/forms';
import { LoginPage } from '../login/login';
import { PasswordApiService } from '../../providers/password-api-service';
import { AlertService } from '../../providers/alert-service';

@Component({
  selector: 'page-redefine-password',
  templateUrl: 'redefine-password.html'
})
export class RedefinePasswordPage {

  resetForm: any;

  constructor(
  	public navCtrl: NavController,
    public navParams: NavParams,
    private formBuilder: FormBuilder,
    public alert: AlertService,
    public passwordApiService: PasswordApiService
  ) {
    const token = this.navParams.get('reset_password_token')

  	this.resetForm = this.formBuilder.group ({
      password: ['', Validators.required],
      password_confirmation: ['', Validators.required],
      reset_password_token: [token, Validators.required]
    })
  }

  // @name submit
  // @description Submit form to reset password
  // @returns void
  public submit(): void {
    this.passwordApiService
        .changePassword(this.resetForm.value)
        .subscribe(this._afterSendNewPassword.bind(this))
  }

  // @name _afterSendNewPassword
  // @description Callback after send password instructions
  // @returns void
  private _afterSendNewPassword(): void {
    this.alert
      .show({ content: 'Sua senha foi alterada. Para sua segurança, faça login para continuar' })
      .then(() => {
        this.navCtrl.setRoot(LoginPage)
      })
  }
}
