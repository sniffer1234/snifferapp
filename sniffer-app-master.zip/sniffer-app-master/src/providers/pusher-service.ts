declare var Pusher: any;

export class PusherService {

  public connection: any

  constructor() {
    this.connection = this.connection || new Pusher('b4a40f5be32b936374f9', {
      encrypted: true
    })
  }

}
