import { Injectable } from '@angular/core'
declare var window: any

@Injectable()
export class EncodeMediaService {

  constructor() {
  }


  public toBase64(path, callback): void {
    window.resolveLocalFileSystemURL(path, gotFile, fail)

    function fail(e) {
      alert('Erro ao enviar Sniff')
    }

    function gotFile(fileEntry) {
      fileEntry.file(function(file) {
        var reader = new FileReader()
        reader.onloadend = function(e) {
          var content = this.result
          callback(content)
        }
        reader.readAsDataURL(file)
      })
    }
  }

}
