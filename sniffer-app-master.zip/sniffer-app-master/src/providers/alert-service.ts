import { Injectable } from '@angular/core'
import { AlertController } from 'ionic-angular'
import { Vibration } from '@ionic-native/vibration'

@Injectable()
export class AlertService {

  constructor(
    public alertCtrl: AlertController,
    private vibration: Vibration
  ) {
  }

  public show(options: any = {}) {
    options.title = options.title || 'Sucesso'

    return new Promise((resolve, reject) => {
      const alert = this.alertCtrl.create({
        enableBackdropDismiss: false,
        title: options.title,
        subTitle: options.content,
        buttons: [{
          text: 'OK',
          handler: () => {
            resolve()
          }
        }]
      })

      if(options.vibrate) {
        this.vibration.vibrate(300)
      }

      alert.present()
    })
  }

  public confirm(options: any = {}) {
    return new Promise((resolve, reject) => {
      let alert = this.alertCtrl.create({
        enableBackdropDismiss: false,
        title: options.title,
        message: options.content,
        buttons: [
          {
            text: 'Cancelar',
            role: 'cancel',
            handler: () => {
            //  reject()
            }
          },
          {
            text: 'Ok',
            handler: () => {
              resolve()
            }
          }
        ]
      })

      alert.present()
    })
  }

}
