import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http-service';
import 'rxjs/add/operator/map';

@Injectable()
export class PasswordApiService {

  constructor(public http: BaseHttpService) {}

  // @name sendInstructions
  // @description Send an email to user for change password
  public sendInstructions(user) {
    return this.http.post('password', {user}).map(res => res.json())
  }

  // @name senchangePassworddInstructions
  // @description Change user password
  public changePassword(user) {
    return this.http.put('password', {user}).map(res => res.json())
  }

}
