import { Injectable } from '@angular/core'
import { ModalController } from 'ionic-angular'

// Components
import { SniffPreviewComponent } from '../components/sniff-preview/sniff-preview'

@Injectable()
export class SniffPreviewFactory {

  resolve: any
  reject: any

  constructor(
    public modalCtrl: ModalController
  ) {
  }

  // @name open
  // @description open modal with preview
  // @params { Object } options - image options
  public open(options: any = {}): any {
    return new Promise((resolve, reject) => {
      this.resolve = resolve
      this.reject = reject

      const modal = this.modalCtrl.create(SniffPreviewComponent, options)

      modal.onDidDismiss(this.onClose.bind(this))
      modal.present()
    })
  }

  private onClose(data: any = {}): void {
    if(data.sniff) {
      this.resolve(data.sniff)
    }
  }

}
