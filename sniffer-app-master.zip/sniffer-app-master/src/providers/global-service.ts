import { Injectable, isDevMode } from '@angular/core'
import { Storage } from '@ionic/storage'
import { Events, Platform } from 'ionic-angular'


@Injectable()
export class GlobalService {
  store: any

  constructor(
    public storage: Storage,
    public events: Events,
    public platform: Platform
  ) {
    // Check if application is in production
    if(!isDevMode()) {

      // Native application
      // Must initialize data after the plataform start
      this.platform.ready().then(this.fetchInitialData.bind(this))
    } else {
      this.fetchInitialData()
    }

    // Listen events from setters
    this.events.subscribe('store:set', this.onSetData.bind(this))
  }

  // @name fetchInitialData
  // @description Fetch data to start
  private fetchInitialData() {
    this.storage.get('store').then(this.afterFetchInitialData.bind(this))
  }

  // @name afterFetchInitialData
  // @description callback after fetch initial data
  // @params { Object } data - Data retrivied on storage
  private afterFetchInitialData(data = null) {

    // Default user data
    // At first time, user will use these data
    let defaultStore = {
      version: 1,
      showedTagToast: false,
      tags: []
    }

    this.store = data || defaultStore

    // Clear storage if versions changed
    // Necessary to force to clear data
    if(this.store.version !== defaultStore.version) {
      this.storage.clear()
      this.store =  defaultStore
    }

    this.events.publish('store:changed', this.store)
  }

  // @name onSetData
  // @description Callback after set data on plain object
  private onSetData(): void {

    // Set data on storage
    this.storage.set('store', this.store)
    this.events.publish('store:changed')
  }

  set session(session: any) {
    this.store.session = session
    this.events.publish('store:set')
  }

  get session(): any {
    return Object.assign({}, this.store.session)
  }

  set tag(tag) {
    let index = -1

    for(let i = 0; i < this.store.tags.length; i++) {
      if(tag.alias === this.store.tags[i].alias) {
        index = i

        if(tag.overwrite) {
          this.store.tags[i] = tag
        }

        break
      }
    }

    if(index === -1) {
      this.store.tags.push({
        name: tag.name,
        alias: tag.alias,
        checked: tag.checked
      })
    }

    this.events.publish('store:set')
  }

  get showedTagToast(): boolean {
    return this.store.showedTagToast
  }

  set showedTagToast(showedTagToast: boolean) {
    this.store.showedTagToast = showedTagToast
    this.events.publish('store:set')
  }

  get tags(): any {
    return this.store.tags
  }

  get isLogged(): boolean {
    return this.store.session && this.store.session.id ? true : false
  }

  set establishments(establishments: any) {
    this.store.establishments = Object.assign({}, establishments)
    this.events.publish('store:set')
  }

  get establishments(): any {
   return Object.assign({}, this.store.establishments)
  }

}
