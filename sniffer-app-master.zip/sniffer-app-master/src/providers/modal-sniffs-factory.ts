// Third part
import { Injectable } from '@angular/core'
import { ModalController } from 'ionic-angular'
import { AlertController } from 'ionic-angular'


// App components
import { ModalSniffsComponent } from '../components/modal-sniffs/modal-sniffs'

// App Services
import { SniffApiService } from './sniff-api-provider'

@Injectable()
export class ModalSniffsFactory {
  constructor(
    public SniffApiService: SniffApiService,
    public modalCtrl: ModalController,
    public alertCtrl: AlertController
  ) {
  }

  // @name open
  // @description open sniffs modals
  // @returns void
  public open(establishment: any = null): any {
    return new Promise((resolve, reject) => {

      // Load sniffs by establishment
      this.SniffApiService
        .getSniffsByEstablishment(establishment)
        .subscribe((res) => {

          if(!res.data.length) {
            const alert = this.alertCtrl.create({
              enableBackdropDismiss: false,
              title: 'Ops..',
              subTitle: 'Esse estabelecimento ainda não possui sniffs!',
              buttons: [{
                text: 'OK'
              }]
            })

            alert.present()
          } else {
            // Open modal with modal sniffs component
            const modal = this.modalCtrl.create(ModalSniffsComponent, {
              sniffs: res.data,
              establishment
            })

            modal.present()

            modal.onDidDismiss((data: any = {}) => {
              resolve(data)
            })
          }
        })
    })
  }
}
