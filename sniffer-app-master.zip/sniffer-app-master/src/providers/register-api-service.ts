import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http-service';
import 'rxjs/add/operator/map';

import { RegisterModel } from '../models/register-model';

@Injectable()
export class RegisterApiService {

  constructor(public http: BaseHttpService) {}

  // @name signup
  // @description Signup user
  // @return Observable<UserModel>
  public signup(user: RegisterModel) {
    return this.http.post('sign_up', {user}).map(res => res.json())
  }

  public confirm(user) {
    return this.http.get('confirmation', user).map(res => res.json())
  }

}
