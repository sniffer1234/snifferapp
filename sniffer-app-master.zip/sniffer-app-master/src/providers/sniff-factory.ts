// Third part
import { Injectable } from '@angular/core'
import { ActionSheetController } from 'ionic-angular'
import { Toast } from '@ionic-native/toast'
import { Vibration } from '@ionic-native/vibration'

// Providers
import { EstablishmentApiService } from './establishment-api-service'
import { MeApiService } from './me-api-service'
import { SniffCameraFactory } from './sniff-camera-factory'
import { SniffEstablishmentsFactory } from './sniff-establishments-factory'
import { SniffPreviewFactory } from './sniff-preview-factory'


@Injectable()
export class SniffFactory {
  resolve: any
  reject: any

  isVideo: boolean = false
  cameraType: string = 'photo'

  establishment: any

  constructor(
    public meApiService: MeApiService,
    public establishmentApiService: EstablishmentApiService,
    public sniffCameraFactory: SniffCameraFactory,
    public sniffPreviewFactory: SniffPreviewFactory,
    public sniffEstablishmentsFactory: SniffEstablishmentsFactory,
    public actionSheetCtrl: ActionSheetController,
    private toast: Toast,
    private vibration: Vibration
  ) {
  }

  // @name send
  // @description initialise process to send a sniff
  // @params { Object } options
  // @returns void
  public send(options: any = {}): any {
    this.establishment =
      options.establishment ?
        options.establishment : null

    return new Promise((resolve, reject) => {
      this.resolve = resolve
      this.reject = reject

      this.chooseMediaType()
    })
  }

  // @name chooseMediaType
  // @description choose media type (video or image)
  // @return Promise
  private chooseMediaType(): any {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Publicar Sniff',
      buttons: [
        { text: 'Tirar foto', icon: 'camera', handler: this.onSelectActionSheet.bind(this, 'photo') },
        { text: 'Gravar vídeo', icon: 'videocam', handler: this.onSelectActionSheet.bind(this, 'video') },
        { text: 'Buscar na galeria', icon: 'images', handler: this.onSelectActionSheet.bind(this, 'gallery') },
        { text: 'Cancelar', icon: 'close', role: 'cancel' },
      ]
    })

    actionSheet.present()
  }

  /**
   * @name onSelectActionSheet
   * @description callback when user press on action sheet option
   * @param {String} type - indicate action type (photo, video or gallery)
   * @returns void
   *
  **/
  private onSelectActionSheet(type: string): void {
    this.cameraType = type

    if(this.establishment) {

      // User has filled establishment, just open the camera
      this.openCamera()
    } else {

      // Necessary select establishment first
      this.sniffEstablishmentsFactory
          .open()
          .then(this.afterCloseSniffsEstablishmentsModal.bind(this))
    }
  }

  // @name afterCloseSniffsEstablishmentsModal
  // @description callback after user close establishments modal
  // @params { Object } data - Data params
  // @returns void
  private afterCloseSniffsEstablishmentsModal(data: any = {}): void {
    if(data.establishment) {
      this.establishment = data.establishment
      this.openCamera()
    }
  }

  /**
   * @name openCamera
   * @description open cordova camera
   * @return {Void}
  **/
  public openCamera(): void {
    if(this.cameraType === 'photo' || this.cameraType === 'gallery') {
      this.openPictureCamera()
    } else {
      if(this.cameraType === 'video') {
        this.openVideoCamera()
      }
    }
  }

  // @name openPictureCamera
  // @description open picture camera
  // @returns void
  public openPictureCamera(): void {
    const options = {
      gallery: this.cameraType === 'gallery'
    }

    this.sniffCameraFactory
        .takePicture(options)
        .then(this.afterTakePicture.bind(this))
  }

  // @name afterTakePicture
  // @description callback after take a picture
  // @params { Object } res - Img data
  // @returns void
  public afterTakePicture(data: any = {}): void {
    this.sniffPreviewFactory.open(data).then(this.create.bind(this))
  }

  // @name openVideoCamera
  // @description open video camera
  // @returns void
  public openVideoCamera(): void {
    this.sniffCameraFactory
        .takeVideo()
        .then(this.create.bind(this))
  }

  // @name create
  // @description create sniff over api
  // @returns void
  private create(options: any = {}): void {
    this.toast.show('Seu sniff está sendo enviado...', '2000', 'bottom').subscribe()

    let data = {
      sniffable_id: this.establishment.id,
      sniffable_type: 'Establishment',
      duration: options.duration
    }

    data[options.key] = options.src

    this.meApiService
        .createSniff(data)
        .subscribe(this.afterSendSniff.bind(this), this.afterSendWithErr.bind(this))
  }

  // @name onSendWithSuccess
  // @description callback after create sniff with success
  // @returns void
  private afterSendSniff(): void {
    this.vibration.vibrate(300)
    this.toast.show('Seu sniff foi enviado', '2000', 'bottom').subscribe()

    this.resolve()
  }

  // @name onSendWithErr
  // @description callback after create sniff with error
  // @returns void
  private afterSendWithErr(): void {
    alert('Erro ao enviar sniff')
    // TODO
  }
}
