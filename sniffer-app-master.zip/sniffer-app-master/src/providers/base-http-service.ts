import { Injectable } from '@angular/core'
import { Observable } from 'rxjs/Rx'
import 'rxjs/add/operator/catch'
import { Http, Response, Headers, URLSearchParams } from '@angular/http'
import { Transfer } from '@ionic-native/transfer'
import { Events, LoadingController } from 'ionic-angular'
import { AlertService } from './alert-service'
import { GlobalService } from './global-service'

@Injectable()
export class BaseHttpService {

  baseApiPath: string
  loader: any = null

  constructor(
    private http: Http,
    public loadingCtrl: LoadingController,
    public events: Events,
    public globalService: GlobalService,
    public alert: AlertService,
    private transfer: Transfer
  ) {
    this.baseApiPath = this.getApiPath()
  }

  // @name getApiPath
  // @description Return API base path
  // @returns string
  private getApiPath(): string {
    return 'http://snifferapp.com/api'
  }

  // @name setRequestParamsAndHeaders
  // @description set HTTP default params / headers
  // @returns void
  private setRequestParamsAndHeaders(headers: Headers, urlParams: URLSearchParams, params: any = {}): void {
    for (var key in params) {
      urlParams.set(key, params[key])
    }

    const { session, isLogged } = this.globalService

    if(isLogged) {
      headers.append('X-User-Email', session.email)
      headers.append('X-User-Token', session.authentication_token)
    }
  }

  // @name get
  // @description HTTP get method
  // @returns Observable
  public get(url: string, params: any = {}, extraParams: any = {}) {
    let headers = new Headers({ 'Content-Type': 'application/json' })
    let search = new URLSearchParams()

    this.setRequestParamsAndHeaders(headers, search, params)

    return this.intercept(this.http.get(`${this.baseApiPath}/${url}`, { headers, search }).timeout(15000), extraParams)
  }

  public postMedia(url: string, data: any = {}, extraParams: any = {}) {
    const fileTransfer = this.transfer.create()

    const options = {
      mimeType: data.mimeType,
      params: data,
      fileKey: data.fileKey,
      fileName:  data.src.substr(data.src.lastIndexOf('/') + 1),
      httpMethod: 'POST',
      headers: {
         'X-User-Email': this.globalService.session.email,
         'X-User-Token': this.globalService.session.authentication_token
      }
    }

    return fileTransfer.upload(options.params.src, `${this.baseApiPath}/${url}`, options)
  }

  // @name post
  // @description HTTP post method
  // @returns Observable
  public post(url: string, data: any = {}, extraParams: any = {}) {
    let headers = new Headers({ 'Content-Type': 'application/json' })
    let search = new URLSearchParams()

    this.setRequestParamsAndHeaders(headers, search)

    return this.intercept(this.http.post(`${this.baseApiPath}/${url}`, data, { headers }).timeout(15000), extraParams)
  }

  // @name post
  // @description HTTP post method
  // @returns Observable
  public put(url: string, data: any = {}, extraParams: any = {}) {
    let headers = new Headers({ 'Content-Type': 'application/json' })
    let search = new URLSearchParams()

    this.setRequestParamsAndHeaders(headers, search)

    return this.intercept(this.http.put(`${this.baseApiPath}/${url}`, data, { headers }).timeout(15000), extraParams)
  }

  // @name intercept
  // @description Intercept all requests
  private intercept(observable: Observable<Response>, extraParams: any = {}): Observable<Response> {
    if(!extraParams.hideLoading) {
      this.showLoading()
    }

    // Error callback
    return observable.catch((err, source) => {
      this.events.publish('request:error', err.json())

      if(!extraParams.hideErrorAlert) {
        this.showError(err)
      } else {
        this.hideLoading()
      }

      return Observable.throw(err)
    }).do(() => {
      if(!extraParams.hideLoading) {
        this.hideLoading()
      }
    })
  }

  // @name showLoading
  // @description Show loading
  private showLoading(): void {
    if(!this.loader) {
      this.loader = this.loadingCtrl.create()
      this.loader.present()
    }
  }

  // @name hideLoading
  // @description Hide loading
  private hideLoading(): void {
    if(this.loader) {
      this.loader.dismissAll()
    }

    this.loader = null
  }

  // @name showError
  // @description Show error messages
  private showError(err): void {
    this.hideLoading()

    err = err.json()

    err = err.error ? err.error.description : 'Um erro inesperado ocorreu'
    this.alert.show({
      title: 'Ops...',
      content: err
    })
  }
}
