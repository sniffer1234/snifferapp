import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';

import { BaseHttpService } from './base-http-service';
import { LoginModel } from '../models/login-model';

@Injectable()
export class LoginApiService {

  constructor(public http: BaseHttpService) {}

  // @name signin
  // @description Signin user
  // @return Observable<UserModel>
  public signin(user: LoginModel): any {
    return this.http.post('sign_in', { user }).map(res => res.json())
  }

  public loginOrRegisterWithFacebook(data: any): any {
    return this.http.post('facebook', data).map(res => res.json())
  }

}
