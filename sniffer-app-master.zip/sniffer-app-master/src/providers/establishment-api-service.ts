import { Injectable } from '@angular/core'
import { BaseHttpService } from './base-http-service'
import 'rxjs/add/operator/map'

import { EstablishmentCollection } from '../models/establishment-collection';

@Injectable()
export class EstablishmentApiService {

  constructor(public http: BaseHttpService) {}

  // @name getOne
  // @description get establishment details
  // @params { Object } establishment - establishment to get details
  public getOne(establishment: any): any {
    return this.http.get(`establishments/${establishment.id}`).map(res => res.json())
  }

  // @name getAll
  // @description Get all establishments
  public getAll(params: any = {}, extraParams: any = {}): any {
    if(params.tags === 'all') {
      delete params.tags;
    }

    return this.http.get('establishments', params, extraParams).map(res => res.json())
  }

  // @name suggest
  // @description create a establishment suggestion
  // @params { Object } establishment - establishment details
  public suggest(establishment: any = {}): any {
    return this.http.post('establishments', establishment).map(res => res.json())
  }

  // @name getEvents
  // @description create a establishment suggestion
  // @params { Object } establishment - establishment details
  public getEvents(establishmentId: number): any {
    return this.http.get(`establishments/${establishmentId}/events`).map(res => res.json())
  }

}
