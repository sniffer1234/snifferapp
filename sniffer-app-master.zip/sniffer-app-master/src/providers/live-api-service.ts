import { Injectable } from '@angular/core'
import { BaseHttpService } from './base-http-service'
import 'rxjs/add/operator/map'

@Injectable()
export class LiveApiService {

  constructor(public http: BaseHttpService) {}

  // @name getAll
  // @description get last sniff by establishments
  public getAll(): any {
    return this.http.get('live').map(res => res.json())
  }

}
