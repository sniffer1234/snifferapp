import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { BaseHttpService } from './base-http-service';

@Injectable()
export class TagsApiService {

  constructor(public http: BaseHttpService) {}

  public getAll(): any {
    return this.http.get('tags').map(res => res.json())
  }

}
