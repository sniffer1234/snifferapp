import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http-service';

import 'rxjs/add/operator/map';

@Injectable()
export class EventApiService {

  constructor(public http: BaseHttpService) {}

  // @name getAll
  // @description get all events
  public getAll(params: any = {}, extraParams = {}): any {
    return this.http.get('events', params, extraParams).map(res => res.json())
  }

  // @name getAll
  // @description get details from a specific event
  // @params { Object } event - event to get details
  public getOne(event: any): any {
  	return this.http.get(`events/${event.id}`).map(res => res.json())
  }

  // @name suggest
  // @description create a event suggestion
  // @params { Object } event - event details
  public suggest(event: any = {}): any {
    return this.http.post('events', event).map(res => res.json())
  }
}
