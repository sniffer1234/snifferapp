import { Injectable } from '@angular/core'
import { ModalController } from 'ionic-angular'

// Providers
import { EstablishmentApiService } from './establishment-api-service'
import { GlobalService } from './global-service'

// Pages
import { SniffEstablishmentPage } from '../pages/sniff-establishment/sniff-establishment'

@Injectable()
export class SniffEstablishmentsFactory {
  establishments: any
  currentUser: any = {}
  resolve: any
  reject: any

  constructor(
    public modalCtrl: ModalController,
    public globalService: GlobalService,
    public establishmentApiService: EstablishmentApiService
  ) {
    this.currentUser = this.globalService.session
  }

  // @name open
  // @description promise to control state of the component
  // @returns Promise
  public open(): any {
    return new Promise((resolve, reject) => {
      this.resolve = resolve
      this.reject = reject

      this.openModal()
    })
  }

  // @name openModal
  // @description open modal with establishments
  // @returns void
  private openModal(): void {
    // Open establishment modal to user choose establishment
    const modal = this.modalCtrl.create(SniffEstablishmentPage, {
      establishments: this.currentUser.establishments
    })

    modal.onDidDismiss(this.afterClose.bind(this))
    modal.present()
  }

  // @name afterClose
  // @description callback after close modal
  // @returns void
  private afterClose(data: any = {}): void {
    if(data.establishment) {
      this.resolve(data)
    }
  }

}
