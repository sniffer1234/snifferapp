import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http-service';
import 'rxjs/add/operator/map';

@Injectable()
export class SniffApiService {

  constructor(public http: BaseHttpService) {}

  // @name getLastSniffsByEstablishments
  // @description return last sniff by establishments
  // @returns Observable
  public getLastSniffsByEstablishments(params: any = {}, extraParams: any = {}): any {
    return this.http.get('establishments/sniffs', params, extraParams).map(res => res.json())
  }

  // @name getSniffsByEstablishment
  // @description return sniffs by establishment
  // @returns Observable
  public getSniffsByEstablishment(establishment: any): any {
    return this.http.get(`establishments/${establishment.id}/sniffs`).map(res => res.json())
  }

}
