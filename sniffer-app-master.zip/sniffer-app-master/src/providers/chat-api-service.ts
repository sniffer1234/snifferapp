import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { BaseHttpService } from './base-http-service';

@Injectable()
export class ChatApiService {

  constructor(public http: BaseHttpService) {}

  // @name getMessagesByEstablishment
  // @description return messages by establishment
  public getMessagesByEstablishment(establishment: any, params: any = {}): any {
    return this.http.get(`establishments/${establishment.id}/chat`, params).map(res => res.json())
  }

  // @name createMessage
  // @description create a message in the establishment
  public createMessage(establishment: any, chat: any, message: any): any {
    return this.http.post(`establishments/${establishment.id}/chat/${chat.id}/chat_messages`, { chat_message: message }, { hideLoading: true, hideErrorAlert: true }).map(res => res.json())
  }

}
