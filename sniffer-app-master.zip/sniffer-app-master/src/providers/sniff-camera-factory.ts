import { Injectable } from '@angular/core'
import { Camera } from '@ionic-native/camera'
import { VideoEditor } from '@ionic-native/video-editor'
import { Toast } from '@ionic-native/toast'

import { EncodeMediaService } from './encode-media-service'


declare var navigator: any;

@Injectable()
export class SniffCameraFactory {
  cameraOptions: any
  galleryOptions: any
  videoOptions: any

  resolve: any
  reject: any

  constructor(
    public encodeMediaService: EncodeMediaService,
    private camera: Camera,
    private toast: Toast,
    private videoEditor: VideoEditor
  ) {
    this.cameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      targetWidth: 810,
      targetHeight: 1080,
    }

    this.galleryOptions = {
      quality: 100,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG
    }

    this.videoOptions = {
      duration: 8
    }
  }

  // @name takePicture
  // @description open native camera
  // @returns promise
  public takePicture(options: any = {}): any {
    return new Promise((resolve, reject) => {
      this.resolve = resolve
      this.reject = reject

      const cameraOptions =
        options && options.gallery ?
          this.galleryOptions : this.cameraOptions

      this.camera.getPicture(cameraOptions)
        .then(
          this.afterTakePicture.bind(this),
          this.afterTakePictureWithErr.bind(this)
        )
    })
  }

  // @name afterGetImage
  // @description Callback after get media with success
  // @params { Object } data - Image data
  // @returns void
  public afterTakePicture(img: any): void {
    const options = {
      src: `data:image/jpeg;base64,${ img }`
    }

    this.resolve(options)
  }

  // @name afterTakePictureWithErr
  // @description Callback after get media with error
  // @params { Object } err - error details
  // @returns void
  public afterTakePictureWithErr(err: any): void {
    // TODO
  }


  public takeVideo(): any {
    return new Promise((resolve, reject) => {
      this.resolve = resolve
      this.reject = reject

      navigator.device.capture.captureVideo(
        this.afterTakeVideo.bind(this),
        this.afterTakeVideoWithErr.bind(this),
        this.videoOptions
      );
    })
  }

  // @name afterTakePictureWithErr
  // @description Callback after get media with error
  // @params { Object } err - error details
  // @returns void
  private afterTakeVideo(data: any): void {
    this.toast.show('Seu vídeo está sendo processado...', '2000', 'bottom').subscribe()

    const video = data[0]

    this.videoEditor.transcodeVideo({
      fileUri: video.fullPath,
      outputFileName: 'output',
      outputFileType: this.videoEditor.OutputFileType.MPEG4,
      videoBitrate: 1000000 / 1.3,
      width: 810,
      height: 1080,
    })

    .then(this.afterTranscodeVideo.bind(this))
    .catch(this.afterTakeVideoWithErr.bind(this))
  }

  private afterTranscodeVideo(fileUri: string): void {
    fileUri = `file://${ fileUri }`

    this.encodeMediaService.toBase64(fileUri, (encodedMedia) => {
      const options = {
        src: encodedMedia,
        key: 'video_data'
      }

      this.resolve(options)
    })
  }

  // @name afterTakePictureWithErr
  // @description Callback after get media with error
  // @params { Object } err - error details
  // @returns void
  private afterTakeVideoWithErr(err: any): void {
    this.toast.show('Oops! Ocorreu um erro ao enviar seu sniff', '2000', 'bottom').subscribe()
  }
}
