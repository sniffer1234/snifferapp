import { IonicErrorHandler } from 'ionic-angular'
//import Raven from 'raven-js'

//Raven.config('https://9818e6a668e54f54adfc4f1c81535211@sentry.io/180552').install()

export class ErrorHandlerService extends IonicErrorHandler {
  handleError(error) {
    super.handleError(error)

    // try {
    //   Raven.captureException(error.originalError || error)
    // }
    // catch(e) {
    //   console.error(e)
    // }
  }
}
