import { Injectable, isDevMode } from '@angular/core'
declare var window: any;

@Injectable()
export class AnalyticsService {

  public log(name: string, params: any = {}, value: any = null): void {
    if(!isDevMode()) {
      window.facebookConnectPlugin.logEvent(name, params, value)
    }
  }

}
