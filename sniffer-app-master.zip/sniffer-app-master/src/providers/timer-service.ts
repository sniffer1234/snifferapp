import { Injectable } from '@angular/core'

@Injectable()
export class TimerService {
  public timeoutId: any
  public intervalId: any
  public start: any
  public duration: any
  public remaining: any
  public onEndCallback: any
  public onChangeCallback: any

  constructor(options: any = {}) {
    this.duration = options.duration
    this.remaining = this.duration
    this.onEndCallback = options.onEnd
    this.onChangeCallback = options.onChange || null

    this.resume()
    return this
  }

  // @name pause
  // @description pause timer
  // returns void
  public pause(): void {
    clearTimeout(this.timeoutId)
    clearInterval(this.intervalId)

    const date: any = new Date()
    this.duration -= date - this.start
    this.remaining = this.duration
  }

  // @name resume
  // @description start ou resume timer
  // returns void
  public resume(): void {
    this.start = new Date()
    this.reset()

    this.timeoutId = setTimeout(() => {
      this.onEndCallback()
    }, this.duration)

    this.intervalId = setInterval(() => {
      this.remaining -= 1000
      this.onChangeCallback(this.remaining)
    }, 1000)
  }

  // @name reset
  // @description reset timer
  // returns void
  public reset(): void {
    clearTimeout(this.timeoutId)
    clearInterval(this.intervalId)
  }

}
