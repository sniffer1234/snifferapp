import { Injectable } from '@angular/core'
import { BaseHttpService } from './base-http-service'

import 'rxjs/add/operator/map'

@Injectable()
export class SuggestionApiService {

  constructor(public http: BaseHttpService) {}

  // @name create
  // @description create a suggestion
  // @params { Object } suggestion - suggestion details
  public create(suggestion: any = {}): any {
    return this.http.post('suggestions', { suggestion }).map(res => res.json())
  }

}
