// Third part
import { Injectable } from '@angular/core'
import { AlertController } from 'ionic-angular'
import { Facebook } from '@ionic-native/facebook'

// Providers
import { LoginApiService } from './login-api-service'
import { GlobalService } from './global-service'

@Injectable()
export class FacebookService {
  resolve: any
  reject: any

  constructor(
    public alertCtrl: AlertController,
    public loginApiService: LoginApiService,
    public globalService: GlobalService,
    private facebook: Facebook
  ) {
  }

  // @description Login with facebook oauth
  // @returns void
  public login(): any {
    return new Promise((resolve, reject) => {
      this.resolve = resolve
      this.reject = reject

      this.facebook.login(['email'])
                   .then(
                     this.afterFacebookPermission.bind(this),
                     this.onLoginWithFacebookGenericErr.bind(this)
                   )
    })
  }

  // @name _fetchFacebookUser
  // @description Callback after user permit login with facebook
  // @returns void
  private afterFacebookPermission(res: any): void {
    const path = `${ res.authResponse.userID }/?fields=id,first_name,last_name,email`

    // Fetch user data
    this.facebook.api(path, ['email'])
                 .then(
                   this.afterFetchFacebookData.bind(this, res.authResponse)
                 )
  }

  // @name _afterFetchFacebookData
  // @description callback after fetch facebook user data with success
  // @params { Object } res - Facebook user data
  // @params { Object } authResponse - Facebook auth response
  // @returns void
  private afterFetchFacebookData(authResponse: any, res: any): void {

    // User do not have an email or is not confirmed
    if(!res.email) {

      // We must prompt the email
      this.promptUserEmail(authResponse, res)
    } else {
      this.loginApiService
        .loginOrRegisterWithFacebook({
          accessToken: authResponse.accessToken,
          uid: authResponse.userID,
          email: res.email,
          name: `${ res.first_name } ${ res.last_name }`,
        }).subscribe(
          (res) => {
            this.resolve(res)
          }
        )
    }
  }

  // @name onLoginWithFacebookGenericErr
  // @description on facebook err
  // @params { Object } res - Error details
  private onLoginWithFacebookGenericErr(res) {
    const alert = this.alertCtrl.create({
      enableBackdropDismiss: false,
      title: 'Ops...',
      subTitle: 'Ocorreu um erro na hora de logar via facebook :(',
      buttons: [{
        text: 'OK'
      }]
    })

    alert.present()
  }


  // @name promptUserEmail
  // @description prompt user to type email
  // @returns void
  private promptUserEmail(authResponse, res): void {

    // Prompt an error message
    const showErrorMessage = () => {
      const alert = this.alertCtrl.create({
        enableBackdropDismiss: false,
        title: 'Ops...',
        subTitle: 'Para autenticação via facebook você deve permitir o compartilhamento do seu nome e email!',
        buttons: [{
          text: 'OK'
        }]
      })

      alert.present()
    }

    let prompt = this.alertCtrl.create({
      title: 'Digite seu email',
      message: 'Para continuar é necessário que você digite seu email.',
      inputs: [
        { name: 'email', placeholder: 'email', type: 'email' },
      ],
      buttons: [
        { text: 'Cancelar', handler: showErrorMessage.bind(this) },
        {
          text: 'Continuar',
          handler: (data) => {

            if(!data.email) {
              return showErrorMessage()
            }

            res.email = data.email
            res.confirm = true

            this.afterFetchFacebookData(authResponse, res)
          }
        }
      ]
    })

    prompt.present()
  }
}
