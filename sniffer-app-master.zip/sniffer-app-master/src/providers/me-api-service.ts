import { Injectable } from '@angular/core'
import { BaseHttpService } from './base-http-service'
import { GlobalService } from './global-service'

declare var FileTransfer: any;
declare var FileUploadOptions: any;



import 'rxjs/add/operator/map'

@Injectable()
export class MeApiService {

  constructor(
    public globalService: GlobalService,
    public http: BaseHttpService
  ) {}

  // @name getSniffs
  // @description get sniffs by current user
  public getSniffs(options: any = {}, extraOptions: any = {}) {
    return this.http.get('me/sniffs', {}, { hideLoading: true }).map(res => res.json())
  }

  // @name updateData
  // @description Update user data
  public update(user) {

    if(user.notifications) {
      user.email_notification = user.notifications.email
      user.push_notification = user.notifications.push
    }

    return this.http.put('me', { user }).map(res => res.json())
  }

  // @name changePassword
  // @description Change user password
  public changePassword(user) {
    return this.http.put('me/password', { user }).map(res => res.json())
  }

  public createSniff(data: any = {}): any {
    return this.http.post('me/sniff', { sniff: data }, { hideLoading: true }).map(res => res.json())
  }

}
