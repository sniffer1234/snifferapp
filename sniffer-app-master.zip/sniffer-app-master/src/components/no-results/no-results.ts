import { Component, Input } from '@angular/core';

@Component({
  selector: 'no-results',
  templateUrl: 'no-results.html'
})
export class NoResultsComponent {

  @Input() collection: any;
  @Input() message: string = 'Nenhum resultado encontrado'
  @Input() icon: string = 'sad'

  constructor() { }

}
