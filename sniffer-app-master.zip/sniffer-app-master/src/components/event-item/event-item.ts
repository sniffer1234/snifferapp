// Third part
import { Component, Input } from '@angular/core';
import { NavController } from 'ionic-angular';

// App Pages
import { EventDetailPage } from '../../pages/event-detail/event-detail';

// App Services
import { EventApiService } from '../../providers/event-api-service';

@Component({
  selector: 'event-item',
  templateUrl: 'event-item.html'
})
export class EventItemComponent {
  @Input() event: any;

  constructor(
  	public navCtrl: NavController,
    public eventApiService: EventApiService
  ) {
  }

  // @name openEventDetail
  // @description open event details
  // @returns void
  public openEventDetail(): void {
    this.eventApiService
        .getOne({ id: this.event.id })
        .subscribe(this._afterLoad.bind(this))
  }

  // @name _afterLoad
  // @description callback after load event details event
  // @params { Object } res - Event details event
  private _afterLoad(res): void {
    this.navCtrl.push(EventDetailPage, {
      event: res.data
    })
  }
}
