import { Component, ViewChild, Input, Output, EventEmitter } from '@angular/core'
import { TimerService } from '../../providers/timer-service'

@Component({
  selector: 'sniff-slide-item',
  templateUrl: 'sniff-slide-item.html'
})
export class SniffSlideItemComponent {
  @ViewChild('media') media // Angular element
  @Output() changeSlide = new EventEmitter() // Output to force to change media when reach the sniffer duration
  @Input() sniff: any // Sniff data
  @Input() index: number // Sniff slide Loop index
  isVideo: boolean = false // Indicate if media is video
  mediaLoaded: boolean = false // Indicate if the media was loaded
  nativeElement: any // Dom element
  timer: any // timer to reference the duration
  remainingTime: number
  wasOnWaiting: boolean = false

  constructor(
  ) {}

  public ngAfterViewInit(): void {
    if(!this.index) this.start()
  }

  // @name _start
  // @description start the slide item
  // @returns void
  public start(): void {
    // We are getting the media using ViewChild
    // to get the DOM. So We have to acess nativeElement
    // prop
    this.nativeElement = this.media.nativeElement

    // Add a flat to indicate if media is video
    this.isVideo =
      this.nativeElement.tagName === 'VIDEO' ?
        true : false

    if(this.isVideo) {
      this._listenVideoEvents()
    } else {
      this._listenImgEvents()
    }
  }

  // @name _loadImageLoad
  // @description listen to image load events
  // @returns void
  private _listenImgEvents(): void {
    if(this.nativeElement.complete){
      this._afterLoadMedia()
    } else {
      this.nativeElement
        .addEventListener('load', this._afterLoadMedia.bind(this))
    }
  }

  // @name _listenVideoEvents
  // @description listen to video load events
  // @returns void
  private _listenVideoEvents(): void {
    if(this.nativeElement.readyState === 4) {
      this._afterLoadMedia()
    } else {
      setTimeout(this._listenVideoEvents.bind(this), 250)
    }
  }

  // @name _afterLoadMedia
  // @description callback after load media
  // @returns void
  private _afterLoadMedia(): void {
    this.mediaLoaded = true
    this.remainingTime = this.sniff.duration / 1000

    if(this.isVideo) {
      this.nativeElement.play()

      this.nativeElement.onwaiting = () => {
        this.wasOnWaiting = true
        this.timer.pause()
      }

      this.nativeElement.onplaying = () => {
        if(this.wasOnWaiting) {
          this.timer.resume()
        }

      }
    }

    const timerOptions = {
      onEnd: () => {
        this.timer.reset()

        this.changeSlide.emit({
          index: this.index
        })
      },
      onChange: (duration) => {
        this.remainingTime = Math.round(duration / 1000)
      },
      duration: this.sniff.duration
    }

    // Set timer to know when the duration ends
    // and force to change the slide
    this.timer = new TimerService(timerOptions)
  }

  // @name toggleVideo
  // @description Play or pause video, according by state
  // @returns void
  public toggleVideoState(): void {
    this.wasOnWaiting = false

    if(this.nativeElement.paused) {
      this.nativeElement.play()
      this.timer.resume()
    } else {
      this.nativeElement.pause()
      this.timer.pause()
    }
  }

  // @name reset
  // @description
  // @returns void
  public reset(): void {
    // Is video, we must stop the player
    if(this.isVideo) {
      this._resetVideo()
    }

    if(this.timer) {
      this._resetTimer()
    }
  }

  // @name _resetVideo
  // @description reset video
  // @returns void
  _resetVideo(): void {
    this.nativeElement.pause()

    // Reset current time
    this.nativeElement.currentTime = 0
  }

  // @name _resetTimer
  // @description reset timer
  // @returns void
  _resetTimer(): void {
    this.timer.reset()
    this.timer = null
  }

}
