// Third part
import { Component } from '@angular/core'
import { ViewController } from 'ionic-angular'
import { Validators, FormBuilder } from '@angular/forms'

// App services
import { AlertService } from '../../providers/alert-service';
import { EventApiService } from '../../providers/event-api-service'

@Component({
  selector: 'suggest-event',
  templateUrl: 'suggest-event.html'
})
export class SuggestEventComponent {

  suggestForm: any

  constructor(
    public viewCtrl: ViewController,
    public formBuilder: FormBuilder,
    public alert: AlertService,
    public eventApiService: EventApiService
  ) {
    this.suggestForm = this.formBuilder.group({
      name: ['', Validators.required],
      suggestion_message: ['', Validators.required]
    })
  }

  public submitSuggestForm(): void {
    this.eventApiService
        .suggest(this.suggestForm.value)
        .subscribe(this._afterSubmit.bind(this))
  }

  private _afterSubmit(res): void {
    this.suggestForm.reset()

    this.alert
      .show({ content: 'Agradecemos pela sugestão. Em breve nossa equipe estará analisando seu pedido.' })
      .then(this.close.bind(this))
  }

  public close(): void {
   this.viewCtrl.dismiss()
  }

}
