// Third part
import { Component, Input } from '@angular/core';
import { NavController, AlertController } from 'ionic-angular';

// Pages
import { EstablishmentDetailPage } from '../../pages/establishment-detail/establishment-detail';
import { ChatPage } from '../../pages/chat/chat';

@Component({
  selector: 'establishment-item',
  templateUrl: 'establishment-item.html'
})
export class EstablishmentItemComponent {
	@Input() establishment: any;

  constructor(
  	public navCtrl: NavController,
    public alertCtrl: AlertController,
  ) {
  }

  // @name openEstablishmentDetail
  // @description Show establishment details
  // @params { String } tab to change
  // @returns void
  public openEstablishmentDetail(tab: string): void {
  	this.navCtrl.push(EstablishmentDetailPage, {
  		establishment: this.establishment
  	});
  }

  // @name openChatPage
  // @description Show establishment chat
  // @returns void
  public openChatPage(): void {
    this.navCtrl.push(ChatPage, {
      establishment: this.establishment
    });
  }
}
