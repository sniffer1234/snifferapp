import { Component, Input } from '@angular/core'
import { Keyboard } from '@ionic-native/keyboard'

import { GlobalService } from '../../providers/global-service'
import { EstablishmentApiService } from '../../providers/establishment-api-service'

@Component({
  selector: 'establishment-search',
  templateUrl: 'establishment-search.html'
})
export class EstablishmentSearchComponent {
  @Input() establishments: any
  search: string = ''

  constructor(
    public EstablishmentApiService: EstablishmentApiService,
    public globalService: GlobalService,
    public keyboard: Keyboard
  ) {
  }

  // @name onSearchType
  // @description On user search
  // @returns void
  public onSearchType(event: any): void {

    if(event) {
      event.preventDefault()
      this.keyboard.close()
    }

    // We will only perform the search if we have 2 or more characters
     if (this.search.trim() === '' || this.search.trim().length < 2) {
       // Load cached establishments
       this._loadCachedEstablishments()
     } else {

       this._loadEstablishments()
     }
  }

  // @name onSearchCancel
  // @description Cancel user search
  // @returns void
  public onSearchCancel(): void {
    this.search = ''
    this.keyboard.close()

    this._loadCachedEstablishments()
  }

  // @name _loadCachedLocals
  // @description Load cached establishments
  // @returns void
  private _loadCachedEstablishments(): void {
    this.establishments.data = this.globalService.establishments.data
    this.establishments.meta = this.globalService.establishments.meta
  }

  // @name _loadEstablishments
  // @description Load establishments
  // returns void
  private _loadEstablishments(): void {
    const search = this.search.trim()

    this.EstablishmentApiService
        .getAll({ search }, { hideLoading: true })
        .subscribe(this._afterLoadEstablishments.bind(this))
  }

  // @name _afterLoadEstablishments
  // @description callback after load establishments
  // @params { Object } response
  // returns void
  private _afterLoadEstablishments(res): void {
    if(JSON.stringify(this.establishments.data) != JSON.stringify(res.data)) {
      this.establishments.data = res.data
      this.establishments.meta = res.meta
    }
  }

}
