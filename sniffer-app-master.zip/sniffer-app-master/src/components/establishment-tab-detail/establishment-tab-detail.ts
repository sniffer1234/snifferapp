import { Component, Input } from '@angular/core'
import { NavController, Platform } from 'ionic-angular'

@Component({
  selector: 'establishment-tab-detail',
  templateUrl: 'establishment-tab-detail.html'
})
export class EstablishmentTabDetailComponent {
  @Input() establishment: any

  constructor(
    public navCtrl: NavController,
    public platform: Platform
  ) {
  }

}
