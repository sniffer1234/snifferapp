// Third part
import { Component, ViewChild } from '@angular/core'
import { ViewController, Select, NavParams } from 'ionic-angular'
  import { StatusBar } from '@ionic-native/status-bar'

@Component({
  selector: 'sniff-preview',
  templateUrl: 'sniff-preview.html'
})
export class SniffPreviewComponent {
  @ViewChild('select') select: Select
  sniff: any

  constructor(
    public viewCtrl: ViewController,
    public navParams: NavParams,
    private statusBar: StatusBar
  ) {
    const src = this.navParams.get('src')

    this.sniff = {
      duration: 8000,
      src
    }
  }

  public ionViewDidLoad(): void {
    this.statusBar.hide()
  }

  public ionViewDidLeave(): void {
    this.statusBar.show()
  }

  // @name send
  // @description send image to API
  // @returns void
  public send(): void {
    const options = {
      duration: this.sniff.duration,
      src: this.sniff.src,
      key: 'img_data'
    }

    this.viewCtrl.dismiss({
      sniff: options
    })
  }

  // @name changeDuration
  // @description
  // @returns void
  public changeDuration(): void {
    this.select.open()
  }

  // @name cancel
  // @description send image to API
  // @returns void
  public cancel(): void {
    this.viewCtrl.dismiss()
  }

}
