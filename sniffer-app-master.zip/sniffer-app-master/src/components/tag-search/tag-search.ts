import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'tag-search',
  templateUrl: 'tag-search.html'
})
export class TagSearchComponent {
  @Input() tags: any;
  @Output() tagSelected = new EventEmitter()
  selectedTag: any = {}

  constructor() {
  }

  searchByTag(tag) {
    if(tag.id === this.selectedTag.id) {
      this.selectedTag = ''
    } else {
      this.selectedTag = tag
    }
    this.tagSelected.emit(this.selectedTag)
  }
}
