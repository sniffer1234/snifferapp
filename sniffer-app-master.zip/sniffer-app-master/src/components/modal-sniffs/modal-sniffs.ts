// Third part
import { Component, ViewChild, ViewChildren } from '@angular/core'
import { Slides, ViewController, NavController, NavParams } from 'ionic-angular'

@Component({
  selector: 'modal-sniffs',
  templateUrl: 'modal-sniffs.html'
})
export class ModalSniffsComponent {

  // Acess Slides component
  @ViewChild(Slides) slides: Slides

  // Acess sniff itens components
  @ViewChildren('sniffItens') sniffItens

  // Sniffs api response
  sniffs: any

  // Sniff's establishment
  establishment: any

  constructor(
    public viewCtrl: ViewController,
    public navCtrl: NavController,
    public navParams: NavParams
  ) {
    this.sniffs = this.navParams.get('sniffs')
    this.establishment = this.navParams.get('establishment')

    setTimeout(() => {
      console.log(this.sniffs)
    }, 2300)
  }

  // @name close
  // @description close modal
  // @returns void
  public close(): void {
    this.viewCtrl.dismiss()
  }

  // @name goToEstablishment
  // @description redirect user to establishment
  // @returns void
  public goToEstablishment(): void {
    this.viewCtrl.dismiss({
      redirectToEstablishment: true,
      establishment: this.establishment
    })
  }

  // @name onSlideChange
  // @description event when slide changes
  // @returns void
  public onSlideChange(options: any = {}): void {

    // Close modal if is the last
    if((this.slides.getActiveIndex() !== this.slides.length())
      || (this.slides.getPreviousIndex() + 1) !== this.slides.length()) {
        this._callSniffItemAction('previous', 'reset')
        this._callSniffItemAction('active', 'start')
    }
  }

  // @name _callSniffItemAction
  // @description
  // @params { String } order -
  // @params { String } method -
  // @returns void
  private _callSniffItemAction(order: string = 'active', method: string = 'start'): void {
    const index =
      order === 'previous' ?
        this.slides.getPreviousIndex() :
        this.slides.getActiveIndex()

    const sniff = this.sniffItens._results[index]

    if(sniff) {
      sniff[method]()
    }
  }

  // @name changeSlide
  // @description change slide using api of ionic
  // @params { Object } oldSlideItem object width current index
  public changeSlide(oldSlideItem: any = {}): void {
    if(this.slides.isEnd()) {

      // There's no more slide itens to show
      // so we close the modal
      this.close()
    } else {
      this.slides.slideNext()
    }
  }
}
