import { Component, Input } from '@angular/core';

@Component({
  selector: 'sniff-item',
  templateUrl: 'sniff-item.html'
})
export class SniffItemComponent {
  @Input() establishment: any
  showBadge: boolean = false

  constructor() {
  }

  public ngAfterViewInit(): void {
    if(this.establishment.showBadge) {
      this.showNewBadge()
    }
  }

  // @name showNewBadge
  // @description method called from parent when a new sniff is posted
  // so we show badge component
  // @returns void
  public showNewBadge(): void {
    setTimeout(() => {
      this.showBadge= true
    })

    // Default duration is 10s
    setTimeout(() => {
      this.showBadge = false
    }, 15000)
  }

}
