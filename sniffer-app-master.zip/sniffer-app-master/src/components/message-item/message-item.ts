// Third part
import { Component, Input, Output, EventEmitter } from '@angular/core'
import { ToastController } from 'ionic-angular'

// App provders
import { GlobalService } from '../../providers/global-service'

@Component({
  selector: 'message-item',
  templateUrl: 'message-item.html'
})
export class MessageItemComponent {

  @Output() resendMessage = new EventEmitter()
  @Input() message: any
  timeoutDuration: number = 5 * 1000
  nameColor: string = '#000'

  constructor(
    public toastCtrl: ToastController,
    public globalService: GlobalService
  ) {
    this.wasSend()
  }

  public ngOnInit(): void {
    const { user } = this.message

    if(this.globalService.session.id !== user.id) {
      this.nameColor = this._setColorByName(`${ user.id }-${ user.name }`)
    }
  }

  // @name _setColorByName
  // @description generate a unique color by string
  // @params { String } str - user id id and user name
  // @returns string
  private _setColorByName(str): string {
    let hash = 0
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash)
    }
    let colour = '#'
    for (let i = 0; i < 3; i++) {
      let value = (hash >> (i * 8)) & 0xFF
      colour += ('00' + value.toString(16)).substr(-2);
    }

    return colour;
  }

  // @name wasSend
  // @description Check if message was send
  // @returns void
  public wasSend(): void {
    setTimeout(() => {
      if(!this.message.id && this.message.not_confirmed) {
        this.message.failed = true
     }
    }, this.timeoutDuration)
  }

  // @name showErrorDetails
  // @description Show toast to notice the error
  // @returns void
  public showErrorDetails(): void {
    if(this.message.failed) {
      const toast = this.toastCtrl.create({
        message: 'Ocorreu um erro ao enviar essa mensagem. Pressione ela para reenviar',
        duration: 3000,
        position: 'bottom'
      })

      toast.present()
    }
  }

  // @name resend
  // @description Resend message
  // @returns void
  public resend(): void {

    // Only resends message if is failed
    if(this.message.failed) {

      // Necessary to update UI state
      this.message.failed = false
      this.message.not_confirmed = true

      // Emite method to chats controller
      this.resendMessage.emit(this.message)

      // Set timeout to update UI state
      this.wasSend()
    }
  }

}
