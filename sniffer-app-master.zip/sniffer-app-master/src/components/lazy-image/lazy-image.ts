import { Component, Input, ViewChild } from '@angular/core';

@Component({
  selector: 'lazy-image',
  templateUrl: 'lazy-image.html'
})
export class LazyImageComponent {

  // Angular dom elements
  @ViewChild('thumb') thumb
  @ViewChild('medium') medium

  // Image settings
  @Input() image: any
  @Input() startSize: string = 'thumb'

  // Image state values
  mediaLoaded: any

  constructor() {
    this.mediaLoaded = {
      thumb: false,
      medium: false,
    }
  }

  public ngAfterViewInit(): void {
    setTimeout(() => {
      if(this.image) {
        this.start(this.startSize)
      } else {
        this.ngAfterViewInit()
      }
    })
  }

  // @name
  // @description
  // @params
  // @returns void
  private start(key: string): void {
    const nativeElement = this[key].nativeElement

    if(nativeElement) {
      if(nativeElement.complete){
        this.afterLoadMedia(key)
      } else {
        nativeElement
          .addEventListener('load', this.afterLoadMedia.bind(this, key))
      }
    }
  }

  // @name
  // @description
  // @params
  // @returns void
  private afterLoadMedia(key: string): void {
    this.mediaLoaded[key] = true

    if(key === 'thumb' && this.medium) {
      this.start('medium')
    }
  }

}
