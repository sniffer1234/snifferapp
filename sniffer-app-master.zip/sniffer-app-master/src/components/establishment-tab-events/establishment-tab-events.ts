import { Component, Input } from '@angular/core'
import { NavController } from 'ionic-angular'
import { EventModel } from '../../models/event-model'
import { EventDetailPage } from '../../pages/event-detail/event-detail'
import { EstablishmentApiService } from '../../providers/establishment-api-service'

@Component({
  selector: 'establishment-tab-events',
  templateUrl: 'establishment-tab-events.html'
})
export class EstablishmentTabEventsComponent {

  @Input() establishment: any;
  events: Array<EventModel> = []

  public constructor(
    public navCtrl: NavController,
    public establishmentApiService: EstablishmentApiService
  ) {
  }

  ngAfterViewInit() {
    this.establishmentApiService
        .getEvents(this.establishment.id)
        .subscribe(this._afterLoad.bind(this))
  }

  private _afterLoad(res): void {
    this.events = res
  }

  openDetail(event) {
    this.navCtrl.push(EventDetailPage, {
      event: event
    })
  }

}
