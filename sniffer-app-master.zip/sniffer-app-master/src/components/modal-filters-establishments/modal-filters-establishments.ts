// App components
import { Component } from '@angular/core'
import { ViewController, NavParams } from 'ionic-angular'

// App Providers
import { GlobalService } from '../../providers/global-service'
import { AlertService } from '../../providers/alert-service'
import { EstablishmentApiService } from '../../providers/establishment-api-service'

@Component({
  selector: 'modal-filters-establishments',
  templateUrl: 'modal-filters-establishments.html'
})
export class ModalFiltersEstablishmentsComponent {
  tags: any
  establishments: any

  constructor(
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public globalService: GlobalService,
    public establishmentApiService: EstablishmentApiService,
    public alert: AlertService
  ) {
    this.establishments = this.navParams.get('establishments')
    this.reset()
  }

  // @name resetFilters
  // @description reset filters
  // @returns void
  public reset(options: any = {}): void {
    let tags = this.navParams.get('tags')
    let tagsSettings = this.globalService.tags

    for(let i in tags) {

      // Set tag provider
      // If tag does not exits on ionic storage, create
      this.globalService.tag = {
        alias: tags[i].alias,
        name: tags[i].name,
        checked: typeof options.checked !== undefined ? options.checked : true,
        overwrite: options.overwrite || false
      }
    }

    this.tags = tagsSettings
  }

  // @name onChangeTag
  // @description change tag
  // @params { Object } tag - tag a ser editada
  // @returns void
  public onChangeTag(tag): void {

    // Necessary to force to edit item on global provider
    tag.overwrite = true

    this.globalService.tag = tag
  }

  // @name applyFilters
  // @description Set filters
  // @returns void
  public apply(): void {
    let filters = []

    // Create filters object to send via api
    for(let i in this.tags) {
      if(this.tags[i].checked) {
        filters.push(this.tags[i].alias)
      }
    }

    // Necessary at last one item to fetch data
    if(filters.length === 0) {
      this.alert.show({
        title: 'Ops...',
        content: 'É necessário marcar pelo menos uma categoria',
        vibrate: true
      })
    } else {
      this.establishmentApiService
          .getAll({ tags: filters.toString() })
          .subscribe(this._afterLoadEstablishments.bind(this))
    }
  }

  // @name _afterLoadEstablishments
  // @description callback after load establishments
  // @params { Object } response
  // returns void
  private _afterLoadEstablishments(res): void {
    this.establishments.data = res.data
    this.establishments.meta = res.meta

    this.viewCtrl.dismiss()
  }

  // @name close
  // @description Close modal
  // @returns void
  public close(): void {
    this.viewCtrl.dismiss()
  }

}
