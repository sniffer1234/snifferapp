// Third part
import { Component, ViewChild } from '@angular/core'
import { Nav, Platform, Events, MenuController } from 'ionic-angular'
import { OneSignal } from '@ionic-native/onesignal'
import { Deeplinks } from '@ionic-native/deeplinks'
import { StatusBar } from '@ionic-native/status-bar'

// Pages
import { MainTabsPage } from '../pages/main-tabs/main-tabs'
import { ProfilePage } from '../pages/profile/profile'
import { LoginPage } from '../pages/login/login'
import { TutorialPage } from '../pages/tutorial/tutorial'
import { RedefinePasswordPage } from '../pages/redefine-password/redefine-password'

// Providers
import { GlobalService } from '../providers/global-service'
import { AlertService } from '../providers/alert-service'

// Models
import { RouteModel } from '../models/route-model'

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav

  rootPage: any = null
  pages: Array<{title: string, component: any}>
  routes: Array<RouteModel> = []

  constructor(
    public platform: Platform,
    public events: Events,
    public alert: AlertService,
    public globalService: GlobalService,
    public menuCtrl: MenuController,
    private oneSignal: OneSignal,
    private deeplinks: Deeplinks,
    private statusBar: StatusBar
  ) {
    this.events.subscribe('store:changed', this._setRootPage.bind(this))
    this.events.subscribe('request:error', this._onRequestError.bind(this))
    this.events.subscribe('logout', this.logout.bind(this))

    this.pages = [
      { title: 'Perfil', component: ProfilePage }
    ]
  }

  public ngAfterViewInit(){
    this.platform.ready().then(this._onPlatformReady.bind(this))
  }

  // @name _onRequestError
  // @description callback when an error happens
  // @params { Object } err - error details
  // returns void
  private _onRequestError(err): void {
    if(err.error && err.error.code) {
      const code = err.error.code
      const activePage = this.nav.getActive().name

      // Redirect user to login page if code is 401
      if(activePage !== 'LoginPage' && code === 401) {
        this.logout()
      }
    }
  }

  // @name setRootPage
  // @description Set initilisation page
  // @returns void
  private _setRootPage(): void {
    if(!this.rootPage) {
      this.rootPage = this.globalService.isLogged ? MainTabsPage : TutorialPage
    }
  }

  // @name logout
  // @description Destroy session
  // @returns void
  public logout(): void {

    // Destroy session
    this.globalService.session = null

    // Redirect to login page
    this.nav.setRoot(LoginPage)
  }

  // @name _onPlatformReady
  // @description callback when plataform is ready to use native plugins
  // @returns void
  private _onPlatformReady(): void {
    this._initDeepLinkers()
    this._initializeOneSignal()
  }

  // @name _initDeepLinkers
  // @description Initialize deep link native plugin
  // @returns void
  private _initDeepLinkers(): void {
    this.deeplinks.routeWithNavController(this.nav, {
      '/admin/password/edit': RedefinePasswordPage
    })
  }

  // @name _initializeOneSignal
  // @description Initialize one signal native plugin
  // @returns void
  private _initializeOneSignal(): void {
    this.oneSignal.startInit('d5b795df-bd89-4cb9-b21a-7898231c2702', '110271737552')

    this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.InAppAlert)
    this.oneSignal.setSubscription(true)

    this.oneSignal.endInit()
  }
}
