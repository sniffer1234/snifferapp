import { NgModule, ErrorHandler } from '@angular/core'
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular'
import { MyApp } from './app.component'
import { IonicStorageModule } from '@ionic/storage'
import { BrowserModule } from '@angular/platform-browser'
import { StatusBar } from '@ionic-native/status-bar'
import { SplashScreen } from '@ionic-native/splash-screen'
import { Vibration } from '@ionic-native/vibration'
import { Camera } from '@ionic-native/camera'
import { Toast } from '@ionic-native/toast'
import { Transfer } from '@ionic-native/transfer'
import { PhotoViewer } from '@ionic-native/photo-viewer'
import { VideoEditor } from '@ionic-native/video-editor'
import { Deeplinks } from '@ionic-native/deeplinks'
import { OneSignal } from '@ionic-native/onesignal'
import { Keyboard } from '@ionic-native/keyboard'
import { SocialSharing } from '@ionic-native/social-sharing'
import { Dialogs } from '@ionic-native/dialogs'
import { HttpModule } from '@angular/http'
import { Facebook } from '@ionic-native/facebook'

// Pages
import { MainTabsPage } from '../pages/main-tabs/main-tabs'
import { TutorialPage } from '../pages/tutorial/tutorial'
import { EstablishmentsPage } from '../pages/establishments/establishments'
import { EstablishmentDetailPage } from '../pages/establishment-detail/establishment-detail'
import { EventsPage } from '../pages/events/events'
import { EventDetailPage } from '../pages/event-detail/event-detail'
import { LivePage } from '../pages/live/live'
import { LoginPage } from '../pages/login/login'
import { ProfilePage } from '../pages/profile/profile'
import { SniffEstablishmentPage } from '../pages/sniff-establishment/sniff-establishment'
import { RecoverPasswordPage } from '../pages/recover-password/recover-password'
import { RedefinePasswordPage } from '../pages/redefine-password/redefine-password'
import { RedefineProfilePasswordPage } from '../pages/redefine-profile-password/redefine-profile-password'
import { RegisterPage } from '../pages/register/register'
import { ChatPage } from '../pages/chat/chat'
import { SendSuggestionPage } from '../pages/send-suggestion/send-suggestion'
import { EditUserDataPage } from '../pages/edit-user-data/edit-user-data'
import { ManageUserNotificationsPage } from '../pages/manage-user-notifications/manage-user-notifications'

// Components
import { ModalFiltersEstablishmentsComponent } from '../components/modal-filters-establishments/modal-filters-establishments'
import { EstablishmentItemComponent } from '../components/establishment-item/establishment-item'
import { SuggestEstablishmentComponent } from '../components/suggest-establishment/suggest-establishment'
import { SuggestEventComponent } from '../components/suggest-event/suggest-event'
import { EventItemComponent } from '../components/event-item/event-item'
import { SniffItemComponent } from '../components/sniff-item/sniff-item'
import { EstablishmentTabDetailComponent } from '../components/establishment-tab-detail/establishment-tab-detail'
import { EstablishmentTabEventsComponent } from '../components/establishment-tab-events/establishment-tab-events'
import { MessageItemComponent } from '../components/message-item/message-item'
import { NoResultsComponent } from '../components/no-results/no-results'
import { EstablishmentSearchComponent } from '../components/establishment-search/establishment-search'
import { ModalSniffsComponent } from '../components/modal-sniffs/modal-sniffs'
import { SniffSlideItemComponent } from '../components/sniff-slide-item/sniff-slide-item'
import { SniffPreviewComponent } from '../components/sniff-preview/sniff-preview'
import { LazyImageComponent } from '../components/lazy-image/lazy-image'

// Services
import { BaseHttpService } from '../providers/base-http-service'
import { ErrorHandlerService } from '../providers/error-handler-service'
import { PasswordApiService } from '../providers/password-api-service'
import { RegisterApiService } from '../providers/register-api-service'
import { LoginApiService } from '../providers/login-api-service'
import { EstablishmentApiService } from '../providers/establishment-api-service'
import { EventApiService } from '../providers/event-api-service'
import { LiveApiService } from '../providers/live-api-service'
import { TagsApiService } from '../providers/tags-api-service'
import { ChatApiService } from '../providers/chat-api-service'
import { GlobalService } from '../providers/global-service'
import { MeApiService } from '../providers/me-api-service'
import { SuggestionApiService } from '../providers/suggestion-api-service'
import { SniffApiService } from '../providers/sniff-api-provider'
import { EncodeMediaService } from '../providers/encode-media-service'
import { AnalyticsService } from '../providers/analytics-service'

// Generic Services
import { PusherService } from '../providers/pusher-service'
import { FacebookService } from '../providers/facebook-service'
import { AlertService } from '../providers/alert-service'

// Factories
import { ModalSniffsFactory } from '../providers/modal-sniffs-factory'
import { SniffFactory } from '../providers/sniff-factory'
import { SniffCameraFactory } from '../providers/sniff-camera-factory'
import { SniffEstablishmentsFactory } from '../providers/sniff-establishments-factory'
import { SniffPreviewFactory } from '../providers/sniff-preview-factory'
import { TagSearchComponent } from '../components/tag-search/tag-search';

@NgModule({
  declarations: [
    MyApp,
    TutorialPage,
    EstablishmentsPage,
    EstablishmentDetailPage,
    EventsPage,
    EventDetailPage,
    LivePage,
    LoginPage,
    ProfilePage,
    RecoverPasswordPage,
    RedefinePasswordPage,
    RedefineProfilePasswordPage,
    RegisterPage,
    ChatPage,
    SendSuggestionPage,
    SniffEstablishmentPage,
    SniffPreviewComponent,
    MessageItemComponent,
    EstablishmentItemComponent,
    SuggestEstablishmentComponent,
    EventItemComponent,
    SuggestEventComponent,
    SniffItemComponent,
    ModalSniffsComponent,
    SniffSlideItemComponent,
    EstablishmentTabDetailComponent,
    EstablishmentTabEventsComponent,
    MainTabsPage,
    EditUserDataPage,
    ManageUserNotificationsPage,
    ModalFiltersEstablishmentsComponent,
    NoResultsComponent,
    EstablishmentSearchComponent,
    LazyImageComponent,
    TagSearchComponent
  ],
  imports: [
    HttpModule,
    BrowserModule,
    IonicModule.forRoot(MyApp, {
        backButtonText: '',
        tabsHideOnSubPages: true,
        mode: 'md'
      }
    ),
    IonicStorageModule.forRoot()
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    TutorialPage,
    EstablishmentsPage,
    EstablishmentDetailPage,
    EventsPage,
    EventDetailPage,
    LivePage,
    LoginPage,
    ProfilePage,
    RecoverPasswordPage,
    RedefinePasswordPage,
    RedefineProfilePasswordPage,
    RegisterPage,
    SniffPreviewComponent,
    EstablishmentItemComponent,
    SuggestEstablishmentComponent,
    EventItemComponent,
    SuggestEventComponent,
    SniffItemComponent,
    ModalSniffsComponent,
    SniffSlideItemComponent,
    EstablishmentTabDetailComponent,
    EstablishmentTabEventsComponent,
    MainTabsPage,
    EditUserDataPage,
    ManageUserNotificationsPage,
    ChatPage,
    SendSuggestionPage,
    SniffEstablishmentPage,
    MessageItemComponent,
    ModalFiltersEstablishmentsComponent,
    NoResultsComponent,
    EstablishmentSearchComponent,
    LazyImageComponent
  ],
  providers: [
    StatusBar,
    SplashScreen,
    Vibration,
    Camera,
    Toast,
    Transfer,
    PhotoViewer,
    VideoEditor,
    Deeplinks,
    OneSignal,
    Keyboard,
    SocialSharing,
    Dialogs,
    Facebook,
    { provide: MeApiService, useClass: MeApiService },
    { provide: ErrorHandler, useClass: ErrorHandlerService },
    { provide: BaseHttpService, useClass: BaseHttpService },
    { provide: PasswordApiService, useClass: PasswordApiService },
    { provide: RegisterApiService, useClass: RegisterApiService },
    { provide: LoginApiService, useClass: LoginApiService },
    { provide: EstablishmentApiService, useClass: EstablishmentApiService },
    { provide: EventApiService, useClass: EventApiService },
    { provide: LiveApiService, useClass: LiveApiService },
    { provide: TagsApiService, useClass: TagsApiService },
    { provide: AlertService, useClass: AlertService },
    { provide: ChatApiService, useClass: ChatApiService },
    { provide: GlobalService, useClass: GlobalService },
    { provide: SniffApiService, useClass: SniffApiService },
    { provide: PusherService, useClass: PusherService },
    { provide: ModalSniffsFactory, useClass: ModalSniffsFactory },
    { provide: SniffFactory, useClass: SniffFactory },
    { provide: SniffCameraFactory, useClass: SniffCameraFactory },
    { provide: SniffEstablishmentsFactory, useClass: SniffEstablishmentsFactory },
    { provide: SniffPreviewFactory, useClass: SniffPreviewFactory },
    { provide: FacebookService, useClass: FacebookService },
    { provide: EncodeMediaService, useClass: EncodeMediaService },
    { provide: SuggestionApiService, useClass: SuggestionApiService },
    { provide: AnalyticsService, useClass: AnalyticsService }
  ]
})
export class AppModule {}
