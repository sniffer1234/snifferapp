export interface EstablishmentModel {
	id: number,
	name: string,
	small_description: string,
	description: string,
	email: string,
	phone: string,
	site: string,
	facebook: string,
	instagram: string,
	vip: boolean,
	cover: string,
	avatar: string
};
