export interface UserModel {
	id: number,
	name: string,
  firstName: string,
  lastName: string,
  email: string
};
