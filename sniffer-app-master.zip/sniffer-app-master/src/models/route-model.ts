export interface RouteModel {
	key: string,
  component: any,
  public: boolean,
  onlyPublic: boolean
};
