export interface SniffModel {
	id: number,
	name: string,
	time: string,
	image: string,
	video: string
};
