export interface EventModel {
	id: number,
	name: string,
	description: string,
	image: string,
	location: string
	establishmentID: number;
};
