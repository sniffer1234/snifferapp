export interface RegisterModel {
	name: string,
  email: string,
  password: string,
  password_confirmation: string
};
