import { EstablishmentModel } from './establishment-model';

export interface EstablishmentCollection {
  data: Array<EstablishmentModel>
};
